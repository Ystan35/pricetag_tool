"""
make_a4_sheet.py
-----------------
Takes the label PNGs that generate_label.py already produces (or any folder
of label images) and tiles them onto standard A4 pages so you can print on a
normal office/home printer instead of the Godex label printer.

The Godex label is 1118x795px (a 1.406:1 landscape rectangle, made for the
203dpi thermal printer's own label stock). This script does NOT re-render
labels -- it just lays out existing label PNGs onto A4 sheets, 12 per page
(3 columns x 4 rows). Each tag also gets its own black frame drawn tightly
around it (in addition to the light-grey cell cut-guide), so it's clearly
boxed off for cutting.

USAGE
-----
    # Tile every PNG in ./output (what the GUI/CLI already save there)
    python make_a4_sheet.py --input-dir output --out sheet.pdf

    # Tile a specific set of files, in the order given
    python make_a4_sheet.py --files output/a.png output/b.png --out sheet.pdf

    # Quick test using the bundled sample_output images
    python make_a4_sheet.py --input-dir sample_output --out sample_sheet.pdf

Output is a single multi-page PDF (one page per 8 labels) at 300 DPI, sized
exactly to A4 (210 x 297mm) -- open it in any PDF viewer and print at
"Actual size / 100%" (NOT "fit to page", which would rescale the labels).
"""
import argparse
import glob
import os

import numpy as np
from PIL import Image, ImageDraw

import generate_label as gl

# --- A4 page geometry, all at 300 DPI (a normal "good quality" print res) ---
DPI = 300
MM_TO_PX = DPI / 25.4

PAGE_W_MM, PAGE_H_MM = 210, 297
PAGE_W = round(PAGE_W_MM * MM_TO_PX)
PAGE_H = round(PAGE_H_MM * MM_TO_PX)

DEFAULT_COLS = 3
ROWS = 4                     # rows per page is fixed; COLS (tags per row) is the
                             # user-facing choice -- 1/2/3/4 all use 4 rows, giving
                             # 4 / 8 / 12 / 16 labels per page respectively
MARGIN_MM = 8                # outer page margin (printer-safe)
GUTTER_MM = 4                # gap between cells, also where cut-lines sit
MARGIN = round(MARGIN_MM * MM_TO_PX)
GUTTER = round(GUTTER_MM * MM_TO_PX)

VALID_COLS = (1, 2, 3, 4)    # the tags-per-row choices exposed in the Preview dialog/CLI

# --- Barcode re-crisping (fixes 4-per-row -- and to a lesser extent
# 3-per-row -- scan failures) ---------------------------------------------
# generate_label.py renders each label's barcode at a fixed real-world
# module width (its own docstrings are explicit: "never resized (resizing
# reintroduces the fractional-pixel blur that caused scan failures)"). This
# file used to violate that by LANCZOS-resampling the WHOLE finished label
# PNG -- barcode included -- down to whatever size the chosen column count
# needs. At 3-per-row that shrinks the barcode's ~0.375mm module down to
# ~0.25mm (already marginal); at 4-per-row it drops to ~0.18mm, well below
# what a handheld scanner can reliably read off plain-paper print (ink/toner
# dot-gain plus the resampling blur close up the narrow bars/spaces).
#
# Fix: after resizing everything else as before, re-render the barcode
# FRESH and PIXEL-NATIVE at the sheet's own 300dpi (never resampled) and
# paste it in, overwriting the blurry scaled-down copy. Candidates are tried
# largest-first so labels get the crispest module width that still fits the
# available (scaled) box width; BARCODE_MIN_MODULE_PX is the floor below
# which we stop shrinking further and just warn instead, since that means
# the layout itself (too many columns for that code's length) is too dense
# to print reliably no matter what we do here.
BARCODE_MODULE_CANDIDATES_PX = (6, 5, 4, 3)
BARCODE_MIN_MODULE_PX = BARCODE_MODULE_CANDIDATES_PX[-1]

# Backwards-compatible module-level names (some callers/tests import these
# directly) -- reflect the default 3-per-row layout.
COLS = DEFAULT_COLS
CELL_W = (PAGE_W - 2 * MARGIN - (COLS - 1) * GUTTER) // COLS
CELL_H = (PAGE_H - 2 * MARGIN - (ROWS - 1) * GUTTER) // ROWS
PER_PAGE = COLS * ROWS


def _grid_geometry(cols):
    """Cell size + per-page count for a given tags-per-row count. Rows are
    always fixed at ROWS -- only the column count (and therefore cell width)
    changes, so fewer columns means larger tags, more columns means smaller,
    denser tags."""
    cell_w = (PAGE_W - 2 * MARGIN - (cols - 1) * GUTTER) // cols
    cell_h = (PAGE_H - 2 * MARGIN - (ROWS - 1) * GUTTER) // ROWS
    return cell_w, cell_h, cols * ROWS


def _cell_origin(col, row, cell_w, cell_h):
    x = MARGIN + col * (cell_w + GUTTER)
    y = MARGIN + row * (cell_h + GUTTER)
    return x, y


def _fit_into(img, box_w, box_h):
    """Scale (down or up) to fit inside box_w x box_h, preserving aspect ratio."""
    scale = min(box_w / img.width, box_h / img.height)
    new_size = (max(1, round(img.width * scale)), max(1, round(img.height * scale)))
    return img.resize(new_size, Image.LANCZOS)


def _autocrop_bbox(img, bg=(255, 255, 255), tol=6):
    """Bounding box (left, top, right, bottom) of the label's actual printed
    artwork, trimming the plain white margin the template canvas leaves
    outside its own border/frame. This is what makes each tag fill its A4
    cell instead of printing smaller than it has to with dead white space
    padding it out on every side.

    `tol` is a small tolerance (not an exact ==255 match) so faint
    anti-aliasing right at the border's edge doesn't get left behind as a
    1px white sliver. Falls back to the full image bounds if nothing
    non-white is found (e.g. a corrupt/blank label), so one bad file can't
    crash the whole batch.
    """
    arr = np.asarray(img.convert("RGB"), dtype=np.int16)
    diff = np.abs(arr - np.array(bg, dtype=np.int16)).max(axis=2)
    mask = diff > tol
    if not mask.any():
        return (0, 0, img.width, img.height)
    ys, xs = np.where(mask)
    return (int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1)


def _code_from_path(path):
    """Both the CLI (generate_label.main) and the GUI save labels as
    '<scan_code or barcode>.png' -- recover that value from the filename so
    we can re-render a fresh barcode for it without needing the original
    product dict."""
    return os.path.splitext(os.path.basename(path))[0]


def _find_barcode_box(template):
    for box in (template or {}).get("boxes", []):
        if box.get("field") == "barcode":
            return box
    return None


def _prepared_label(path, autocrop, image_cache):
    """Opened + (optionally) autocropped source image for `path`, reused
    across calls that share the same `image_cache` dict instead of
    re-reading the file and re-running the numpy autocrop scan every time.

    Keyed by (path, autocrop, mtime) so an on-disk change to the file (a
    re-render, e.g. after editing the template and printing again) is
    picked up automatically instead of serving a stale cached crop.
    """
    if image_cache is None:
        label = Image.open(path).convert("RGB")
        if autocrop:
            crop_l, crop_t, crop_r, crop_b = _autocrop_bbox(label)
            return label.crop((crop_l, crop_t, crop_r, crop_b)), (crop_l, crop_t)
        return label, (0, 0)

    try:
        mtime = os.path.getmtime(path)
    except OSError:
        mtime = None
    key = (path, autocrop)
    cached = image_cache.get(key)
    if cached is not None and cached[0] == mtime:
        return cached[1], cached[2]

    label = Image.open(path).convert("RGB")
    if autocrop:
        crop_l, crop_t, crop_r, crop_b = _autocrop_bbox(label)
        source = label.crop((crop_l, crop_t, crop_r, crop_b))
        origin = (crop_l, crop_t)
    else:
        source, origin = label, (0, 0)
    image_cache[key] = (mtime, source, origin)
    return source, origin


def _batch_scale(label_paths, cell_w, cell_h, autocrop=True, image_cache=None):
    """The scale factor _fit_into() will apply to every label in this
    batch. Assumes (as the rest of this module already does -- one call to
    build_pages is always one template/print job) that every label shares
    the same source size (and, with autocrop on, the same border/margin
    layout, since they all come from the same background template), so
    it's safe to read just the first file rather than open all of them
    twice."""
    source, _ = _prepared_label(label_paths[0], autocrop, image_cache)
    w, h = source.size
    return min(cell_w / w, cell_h / h), w, h


def _pick_batch_module_width(label_paths, box, box_w_px, scale):
    """Pick ONE module width shared by every barcode in this print job.

    Choosing per-code independently (module width = whatever's largest
    that still fits THAT code's own barcode) makes a short code like "2300"
    print with visibly fatter, taller-looking bars than a long code like
    "270011263000" sitting right next to it on the same sheet -- reliably
    scannable individually, but inconsistent and unprofessional-looking
    printed side by side. A real price-tag sheet should have one uniform
    barcode size throughout.

    Tries each candidate largest-first; a candidate "wins" for the batch
    once every code in it fits within box_w_px at that module width (or we
    hit the floor, at which point we use it anyway and rely on
    _recrisp_barcode's per-label fallback to warn about any individual
    outlier code that still doesn't fit).

    `scale` is the cell-fit factor applied to the label image and to
    box_w/box_h (_batch_scale / _fit_into) -- it's a PIXEL ratio between the
    label's native render (gl.LABEL_DPI, 203) and the sheet's own render
    (DPI, 300), so it already bakes in that 203->300 dpi jump. module_height_mm,
    font_size and text_distance are physical (mm/pt) quantities that get
    converted to px purely by whatever dpi we pass to make_barcode_image
    (300 here) -- multiplying them by the raw pixel-ratio `scale` would
    double-apply the dpi jump on top of the real size change and still
    render a barcode taller than its box. The actual physical shrink ratio
    is `scale * gl.LABEL_DPI / DPI`; that's what physical/mm-based values
    must use instead, or the re-rendered barcode keeps ballooning past the
    tag frame at 3-/4-per-row (and even at 1-per-row, since the DPI jump
    alone already overshoots). Only module_width_px (already whole px,
    chosen from the candidate list against box_w_px, itself already in
    page-pixel space) is exempt from this correction.

    Returns (module_px, {code: rendered_image}) -- the render cache lets
    build_pages reuse these images directly instead of re-rendering.
    """
    codes = [_code_from_path(p) for p in label_paths]
    codes = sorted({c for c in codes if c})
    if not codes:
        return BARCODE_MODULE_CANDIDATES_PX[0], {}

    physical_scale = scale * gl.LABEL_DPI / DPI
    module_height_mm = max(0.1, box.get("module_height_mm", 9) * physical_scale)

    for module_px in BARCODE_MODULE_CANDIDATES_PX:
        rendered = {}
        overflow = False
        for code in codes:
            # Bars only -- see generate_label.py's make_barcode_image
            # write_text docstring for why the human-readable number is
            # drawn separately rather than by python-barcode itself.
            bc = gl.make_barcode_image(
                code,
                module_width_px=module_px,
                module_height_mm=module_height_mm,
                quiet_zone_mm=box.get("quiet_zone_mm", 2.5),
                dpi=DPI,
                write_text=False,
            )
            rendered[code] = bc
            if bc.width > box_w_px:
                overflow = True
        if not overflow or module_px == BARCODE_MODULE_CANDIDATES_PX[-1]:
            return module_px, rendered
    return BARCODE_MIN_MODULE_PX, rendered  # unreachable, satisfies linters


def _recrisp_barcode(page, draw, path, off_x, off_y, fitted_h, scale, box, module_px, cache):
    """Erase the blurry, resampled barcode that _fit_into() already pasted
    for this label and replace it with a freshly-rendered, pixel-native
    barcode at the sheet's own DPI -- see BARCODE_MODULE_CANDIDATES_PX above
    for why. Uses the batch's shared module_px (from _pick_batch_module_width)
    so every tag on the sheet has the same bar thickness; only shrinks
    further, just for this one label, if this particular code is an outlier
    that doesn't actually fit at the shared width. Silently no-ops (leaving
    the resampled barcode in place) if the code/template/box can't be
    resolved, so a missing template box never breaks sheet generation.

    `fitted_h` is the scaled label's total height (off_y + fitted_h is the
    tag's own bottom edge / frame line) -- the real ceiling the re-rendered
    barcode must not cross. box_h (the template's nominal barcode box
    allocation) is NOT that ceiling: even the unscaled, native-DPI barcode
    render is taller than its own template box_h (there's slack in the
    template layout below the box), so comparing against box_h alone flags
    false positives on every render, scaled or not.

    box's own edge_margin_px (same key generate_label.py's single-label
    path reads, default 20 template-px) is reserved on the right (where
    align="right" would otherwise butt the barcode's own whitespace flush
    against box_w) and on the bottom (against the real available_h
    ceiling, not just box_h) -- without it, a barcode that's merely
    "shorter than available_h" can still land close enough to the tag's
    printed border artwork to visibly paint over it, since nothing here
    previously reserved any clearance at all.
    """
    code_value = _code_from_path(path)
    if not code_value:
        return

    box_x = box.get("x", 0) * scale
    box_y = box.get("y", 0) * scale
    box_w = max(1, box.get("w", 400) * scale)
    bx0, by0 = off_x + box_x, off_y + box_y

    margin_px = max(0, box.get("edge_margin_px", 50)) * scale
    fit_w = max(1, box_w - margin_px)
    available_h = max(1, fitted_h - box_y)
    fit_h = max(1, available_h - margin_px)

    # Erase the old barcode pixels for the *entire* available room down to
    # the tag's real bottom edge, not just the nominal box_h -- the old
    # resampled barcode can itself extend past box_h (same "slack" the
    # docstring above describes), so an erase limited to box_h can leave a
    # blurry remnant sitting right next to the border once the crisp one
    # is pasted in above it.
    draw.rectangle([bx0, by0, bx0 + box_w, by0 + available_h], fill=(255, 255, 255))

    bc_img = cache.get(code_value)
    cur_module_w = module_px
    if bc_img is None or bc_img.width > fit_w:
        # This one code doesn't fit at the batch's shared module width
        # (e.g. it's unusually long compared to the rest of the job) --
        # shrink just for this label rather than let it overflow the tag.
        # Every other label on the sheet keeps the shared, uniform width.
        # Physical (not raw pixel-ratio) shrink factor -- see the long note
        # in _pick_batch_module_width on why `scale` alone double-applies
        # the 203->300 dpi jump for mm/pt-based values.
        physical_scale = scale * gl.LABEL_DPI / DPI
        smaller_candidates = [m for m in BARCODE_MODULE_CANDIDATES_PX if m < module_px] or [BARCODE_MIN_MODULE_PX]
        for smaller in smaller_candidates:
            candidate = gl.make_barcode_image(
                code_value,
                module_width_px=smaller,
                # Same scale-down as _pick_batch_module_width -- this is the
                # per-outlier-code fallback path, it must not silently
                # revert to full native height while everything else on
                # the sheet is scaled, or this one label's barcode overflows
                # the tag frame even though the batch-wide one doesn't.
                module_height_mm=max(0.1, box.get("module_height_mm", 9) * physical_scale),
                quiet_zone_mm=box.get("quiet_zone_mm", 2.5),
                dpi=DPI,
                write_text=False,
            )
            cur_module_w = smaller
            if candidate.width <= fit_w or smaller == BARCODE_MIN_MODULE_PX:
                bc_img = candidate
                break
        if bc_img.width > fit_w:
            print(
                f"  WARNING: barcode for '{code_value}' is wider than its "
                f"box even at the {BARCODE_MIN_MODULE_PX}px floor -- this "
                f"layout may be too dense for this code to print reliably."
            )

    # Human-readable number, drawn ourselves the same way generate_label.py
    # does for the single-label path -- see make_barcode_image's
    # write_text docstring. number_font_size/number_gap_px are plain pixel
    # sizes against the label's native 1118x795 canvas (not mm/dpi-based
    # like the bars), so they scale with the same raw pixel ratio `scale`
    # used for box x/y/w -- NOT physical_scale, which only corrects for
    # the barcode module's own mm/dpi math.
    number_font_size = max(8, round(box.get("number_font_size", 46) * scale))
    number_gap_px = max(0, box.get("number_gap_px", 10) * scale)
    min_number_font_size = max(8, round(box.get("min_number_font_size", 24) * scale))
    min_module_height_mm = max(0.1, box.get("min_module_height_mm", 3.0) * scale * gl.LABEL_DPI / DPI)

    number_font = gl._title_font(number_font_size)
    number_w = draw.textlength(code_value, font=number_font)

    # Height wasn't shrunk anywhere above (module_px is picked on width
    # alone) -- if bars + gap + number don't clear fit_h, shrink the
    # physical bar height first (module_height_mm), same as the
    # single-label path; only once that's hit its own floor does the
    # number's own font start shrinking, so the printed number stays
    # legible even on the densest (4-per-row) layouts.
    module_height_mm = max(0.1, box.get("module_height_mm", 9) * scale * gl.LABEL_DPI / DPI)
    for _ in range(6):
        total_h = bc_img.height + number_gap_px + number_font_size
        if total_h <= fit_h:
            break
        if module_height_mm > min_module_height_mm:
            module_height_mm = max(min_module_height_mm, module_height_mm * 0.85)
            bc_img = gl.make_barcode_image(
                code_value,
                module_width_px=cur_module_w,
                module_height_mm=module_height_mm,
                quiet_zone_mm=box.get("quiet_zone_mm", 2.5),
                dpi=DPI,
                write_text=False,
            )
        elif number_font_size > min_number_font_size:
            number_font_size = max(min_number_font_size, round(number_font_size * 0.9))
            number_font = gl._title_font(number_font_size)
            number_w = draw.textlength(code_value, font=number_font)
        else:
            break

    while number_w > fit_w and number_font_size > 8:
        number_font_size -= 1
        number_font = gl._title_font(number_font_size)
        number_w = draw.textlength(code_value, font=number_font)

    if bc_img.height + number_gap_px + number_font_size > fit_h:
        # This is the real overflow check -- would the barcode's bottom
        # edge cross the tag's own bottom edge (the frame line drawn around
        # the fitted label) or its edge_margin_px clearance from it? Warn
        # loudly instead of quietly letting that print past the tag.
        print(
            f"  WARNING: barcode+number for '{code_value}' is taller "
            f"({bc_img.height + number_gap_px + number_font_size:.0f}px) than the room "
            f"left in its tag after its edge margin ({fit_h:.0f}px) at "
            f"this layout -- check this label before printing."
        )

    ok = gl.barcode_selftest(code_value, bc_img)
    if ok is False:
        print(f"  WARNING: re-rendered barcode for '{code_value}' failed self-decode -- check before printing.")

    align = box.get("align", "left")
    if align == "right":
        paste_x = bx0 + max(0, fit_w - bc_img.width)
    elif align == "center":
        paste_x = bx0 + max(0, (fit_w - bc_img.width) / 2)
    else:
        paste_x = bx0
    page.paste(bc_img, (round(paste_x), round(by0)))

    number_color = tuple(box.get("number_color", [0, 0, 0]))
    number_x = paste_x + max(0, (bc_img.width - number_w) / 2)
    number_y = by0 + bc_img.height + number_gap_px
    draw.text((number_x, number_y), code_value, font=number_font, fill=number_color)


def build_pages(label_paths, cols=DEFAULT_COLS, cut_lines=True, template=None, autocrop=True, image_cache=None):
    """Tile label_paths onto A4 pages, `cols` tags per row (1-4),
    ROWS rows per page.

    `template` is the template each label's barcode box should be read from
    (defaults to whatever's currently active) -- used to re-render every
    barcode crisp, at one shared module width for the whole batch, instead
    of resampling the blurry pre-baked one. Labels are otherwise resized as
    plain images.

    `autocrop` trims the plain white margin the template canvas leaves
    outside its own border (see _autocrop_bbox) before fitting each label
    into its cell, so the printed tag fills as much of the cell as
    possible instead of that white margin eating into the size it prints
    at. On by default; pass False to fall back to the old behaviour
    (fit the raw, uncropped 1118x795 canvas).

    `image_cache` is an optional dict the caller can pass in and reuse
    across multiple build_pages() calls for the *same* set of label files
    (e.g. the Preview window re-tiling the same batch at a different
    tags-per-row layout) -- each label's opened + autocropped source image
    is then read from disk and autocrop-scanned only once no matter how
    many times the layout changes, instead of redoing that work on every
    single column switch. Pass nothing (the default) for a one-off call.
    """
    if cols not in VALID_COLS:
        raise ValueError(f"cols must be one of {VALID_COLS}, got {cols!r}")
    if not label_paths:
        return []

    cell_w, cell_h, per_page = _grid_geometry(cols)

    if template is None:
        try:
            template = gl.get_active_template()
        except Exception:
            template = None
    barcode_box = _find_barcode_box(template)

    module_px, barcode_cache = None, {}
    if barcode_box is not None:
        scale, _, _ = _batch_scale(label_paths, cell_w, cell_h, autocrop=autocrop, image_cache=image_cache)
        margin_px_tpl = max(0, barcode_box.get("edge_margin_px", 50))
        box_w_px = max(1, (barcode_box.get("w", 400) - margin_px_tpl) * scale)
        module_px, barcode_cache = _pick_batch_module_width(label_paths, barcode_box, box_w_px, scale)

    pages = []
    for i in range(0, len(label_paths), per_page):
        chunk = label_paths[i:i + per_page]
        page = Image.new("RGB", (PAGE_W, PAGE_H), "white")
        draw = ImageDraw.Draw(page)

        for idx, path in enumerate(chunk):
            col = idx % cols
            row = idx // cols
            x, y = _cell_origin(col, row, cell_w, cell_h)

            if cut_lines:
                draw.rectangle(
                    [x, y, x + cell_w, y + cell_h],
                    outline=(180, 180, 180),
                    width=1,
                )

            source, (crop_l, crop_t) = _prepared_label(path, autocrop, image_cache)
            fitted = _fit_into(source, cell_w, cell_h)
            off_x = x + (cell_w - fitted.width) // 2
            off_y = y + (cell_h - fitted.height) // 2
            page.paste(fitted, (off_x, off_y))

            if barcode_box is not None:
                scale = fitted.width / source.width
                # barcode_box's x/y are in the ORIGINAL (uncropped) label's
                # 1118x795 reference frame -- shift them by the crop offset
                # so they still land in the right spot on the cropped,
                # then-rescaled label actually pasted onto the page.
                shifted_box = dict(barcode_box)
                shifted_box["x"] = barcode_box.get("x", 0) - crop_l
                shifted_box["y"] = barcode_box.get("y", 0) - crop_t
                _recrisp_barcode(page, draw, path, off_x, off_y, fitted.height, scale, shifted_box, module_px, barcode_cache)

            # frame drawn tight around the actual tag (not the whole cell),
            # so each price tag is clearly boxed off on its own
            draw.rectangle(
                [off_x, off_y, off_x + fitted.width - 1, off_y + fitted.height - 1],
                outline=(0, 0, 0),
                width=2,
            )

        pages.append(page)
    return pages


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", help="Folder of label PNGs to tile (all .png files, sorted by name)")
    parser.add_argument("--files", nargs="+", help="Explicit list of label PNG paths, in order")
    parser.add_argument("--out", default="a4_sheets.pdf", help="Output PDF path (default: a4_sheets.pdf)")
    parser.add_argument(
        "--cols", type=int, choices=VALID_COLS, default=DEFAULT_COLS,
        help="Tags per row: 2, 3 (default), or 4. Rows per page is always 4.",
    )
    parser.add_argument("--no-cut-lines", action="store_true", help="Don't draw the light-grey cut guides around each label")
    parser.add_argument(
        "--no-autocrop", action="store_true",
        help="Don't trim the label's outer white margin before fitting it into its cell (old behaviour).",
    )
    args = parser.parse_args()

    if args.files:
        label_paths = args.files
    elif args.input_dir:
        label_paths = sorted(glob.glob(os.path.join(args.input_dir, "*.png")))
    else:
        parser.print_help()
        return

    if not label_paths:
        print("No label PNGs found.")
        return

    pages = build_pages(label_paths, cols=args.cols, cut_lines=not args.no_cut_lines, autocrop=not args.no_autocrop)
    per_page = args.cols * ROWS
    print(f"{len(label_paths)} label(s) -> {len(pages)} A4 page(s) ({args.cols}x{ROWS} = {per_page} per page, {args.cols} tags per row)")

    first, rest = pages[0], pages[1:]
    first.save(args.out, "PDF", resolution=DPI, save_all=True, append_images=rest)
    print(f"Saved {args.out}")


if __name__ == "__main__":
    main()
