"""
make_icon.py -- generates assets/icon.ico, the favicon used for the app
window and the desktop shortcut.

Draws a simple price-tag glyph (yellow -> green gradient, like the real
label template) with a red "RM" mark, so the icon reads as "price tag
tool" at a glance even at 16x16 taskbar size.

Run once whenever you want to regenerate the icon:
    python make_icon.py
"""
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_PATH = os.path.join(HERE, "assets", "icon.ico")
FONT_TITLE = os.path.join(HERE, "assets", "fonts", "ArchivoBlack-Regular.ttf")

# Brand gradient endpoints sampled from assets/template_real.png
COLOR_TOP = (255, 221, 0)      # yellow
COLOR_BOTTOM = (0, 168, 89)    # green
COLOR_RM = (214, 22, 22)       # red
COLOR_OUTLINE = (30, 30, 30)

SIZE = 256  # master canvas; ICO frames are downscaled from this


def _tag_mask(size):
    """A rounded-rect price-tag silhouette with a punched hole, top-left."""
    mask = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(mask)
    pad = round(size * 0.06)
    radius = round(size * 0.16)
    d.rounded_rectangle([pad, pad, size - pad, size - pad], radius=radius, fill=255)
    hole_r = round(size * 0.07)
    hole_cx = round(size * 0.28)
    hole_cy = round(size * 0.28)
    d.ellipse(
        [hole_cx - hole_r, hole_cy - hole_r, hole_cx + hole_r, hole_cy + hole_r],
        fill=0,
    )
    return mask


def _gradient(size, top, bottom):
    grad = Image.new("RGB", (1, size), 0)
    for y in range(size):
        t = y / max(1, size - 1)
        px = tuple(round(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        grad.putpixel((0, y), px)
    return grad.resize((size, size))


def make_icon():
    base = _gradient(SIZE, COLOR_TOP, COLOR_BOTTOM)
    mask = _tag_mask(SIZE)

    canvas = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    canvas.paste(base, (0, 0), mask)

    # outline the tag shape so it stays legible on light OS backgrounds
    draw = ImageDraw.Draw(canvas)
    pad = round(SIZE * 0.06)
    radius = round(SIZE * 0.16)
    draw.rounded_rectangle(
        [pad, pad, SIZE - pad, SIZE - pad], radius=radius, outline=COLOR_OUTLINE, width=round(SIZE * 0.02)
    )
    hole_r = round(SIZE * 0.07)
    hole_cx = round(SIZE * 0.28)
    hole_cy = round(SIZE * 0.28)
    draw.ellipse(
        [hole_cx - hole_r, hole_cy - hole_r, hole_cx + hole_r, hole_cy + hole_r],
        outline=COLOR_OUTLINE,
        width=round(SIZE * 0.015),
    )

    # "RM" mark, bold, centered in the lower-right two-thirds of the tag
    font = ImageFont.truetype(FONT_TITLE, round(SIZE * 0.34))
    text = "RM"
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    tx = SIZE * 0.58 - tw / 2 - bbox[0]
    ty = SIZE * 0.60 - th / 2 - bbox[1]
    # thin dark outline behind the red fill so it pops on both yellow and green
    for dx, dy in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
        draw.text((tx + dx, ty + dy), text, font=font, fill=(255, 255, 255, 235))
    draw.text((tx, ty), text, font=font, fill=COLOR_RM)

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    canvas.save(OUT_PATH, format="ICO", sizes=sizes)
    print(f"Saved {OUT_PATH}")


if __name__ == "__main__":
    make_icon()
