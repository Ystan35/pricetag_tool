"""
test_barcode_batch.py
----------------------
The exact test I ran against your sku-descriptions.json file, cleaned up
into one script. Run it from inside the pricetag_tool folder:

    python test_barcode_batch.py sku-descriptions.json

Two checks, for every item in the file:

  1. RENDER CHECK -- does compose_label() run without throwing an exception?
     (Would catch things like a font failing to load, bad description text,
     etc. -- crashes that would show up as "No labels could be rendered".)

  2. DECODE CHECK -- after generating the barcode image, does pyzbar/zbar
     (the same decoding engine your handheld scanner uses) read it back and
     get the *same* code out? This is the actual scannability test -- it
     catches cases where the barcode image itself is subtly wrong (bad
     module width, encoding glitch, etc.) even if nothing crashed.

Both checks came back 0 failures across all 11,834 items in the file you
sent, using a placeholder price of RM 9.99 (the file has no price field).
That means the barcode *data/image generation* isn't the problem -- if
specific printed labels are failing to scan, it's very likely a print-side
issue (toner/ribbon running low partway through a big job, a printer driver
hiccup on a later page, physical damage/smudging, etc.) rather than a bug
in this code.

Results get written to:
  - render_fails.txt  (one line per item that raised an exception)
  - decode_fails.txt  (one line per item whose barcode didn't decode cleanly)
Both files are empty/absent if there were no failures.
"""
import json
import sys

import generate_label as gl

CONTENT_LEFT = 90
CONTENT_RIGHT = 1065


def main():
    if len(sys.argv) < 2:
        print("Usage: python test_barcode_batch.py <sku-descriptions.json>")
        return

    with open(sys.argv[1], "r", encoding="utf-8") as f:
        data = json.load(f)

    render_fails = []
    decode_fails = []
    max_w = int((CONTENT_RIGHT - CONTENT_LEFT) * 0.46)

    for i, item in enumerate(data):
        code = item["barcode"]
        desc = item["description"]

        # 1. Render check
        product = {"description": desc, "price": "9.99", "uom": "UNIT", "scan_code": code}
        try:
            gl.compose_label(product)
        except Exception as e:
            render_fails.append(f"{i}\t{code}\t{desc}\t{e!r}")
            continue  # can't barcode-check a label that didn't even render

        # 2. Decode check (scannability)
        bc_img = gl.make_barcode_image(code)
        if bc_img.width > max_w:
            bc_img = gl.make_barcode_image(code, module_width_px=2)
        ok = gl.barcode_selftest(code, bc_img)
        if ok is False:
            decode_fails.append(f"{i}\t{code}\t{desc}")

        if i % 1000 == 0:
            print(f"...{i}/{len(data)}", flush=True)

    with open("render_fails.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(render_fails))
    with open("decode_fails.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(decode_fails))

    print(f"\nTotal: {len(data)} items")
    print(f"Render failures: {len(render_fails)}  -> render_fails.txt")
    print(f"Decode failures: {len(decode_fails)}  -> decode_fails.txt")


if __name__ == "__main__":
    main()
