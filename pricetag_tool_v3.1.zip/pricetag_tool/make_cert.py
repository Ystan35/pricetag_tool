"""
make_cert.py
------------
Run this once (from the pricetag_tool folder) to generate a self-signed
TLS certificate for serving both the flag server and the Price Checker PWA
over HTTPS on the local network.

Why this is needed: phone browsers only allow camera access (getUserMedia,
used for both barcode scanning and QR pairing) on a "secure context" --
HTTPS, or localhost. A plain http://192.168.x.x LAN address doesn't count,
even though the traffic never leaves your network. A self-signed cert over
HTTPS satisfies the browser's secure-context check; staff just need to
accept a one-time certificate warning per phone (or you can install the
cert as a trusted CA on each phone to skip the warning -- see
HTTPS-SETUP.md).

Usage:
    python make_cert.py

Produces cert.pem and key.pem in this folder, valid for 10 years, with
the certificate's Subject Alternative Names covering:
  - EVERY private IPv4 address this machine currently has (auto-detected --
    see netinfo.py; a machine with a VPN, Docker Desktop, or a virtual
    network adapter installed can have several, and the phone-reachable one
    isn't always the first guess, so all of them go in the cert)
  - localhost / 127.0.0.1
  - any extra hostnames/IPs passed as command-line arguments

Re-run this if the machine's LAN IP changes (e.g. after a router reset) --
old cert.pem/key.pem are overwritten.
"""
import datetime
import sys

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

from netinfo import list_lan_ips


def main():
    extra_names = sys.argv[1:]
    lan_ips = list_lan_ips()

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name(
        [x509.NameAttribute(NameOID.COMMON_NAME, "Price Tag Tool (LAN, self-signed)")]
    )

    san_entries = [
        x509.DNSName("localhost"),
        x509.IPAddress(__import__("ipaddress").ip_address("127.0.0.1")),
    ]
    for lan_ip in lan_ips:
        try:
            san_entries.append(x509.IPAddress(__import__("ipaddress").ip_address(lan_ip)))
        except ValueError:
            pass
    for name in extra_names:
        try:
            san_entries.append(x509.IPAddress(__import__("ipaddress").ip_address(name)))
        except ValueError:
            san_entries.append(x509.DNSName(name))

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=1))
        .not_valid_after(datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
        .sign(key, hashes.SHA256())
    )

    with open("key.pem", "wb") as f:
        f.write(
            key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption(),
            )
        )
    with open("cert.pem", "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    print("Wrote cert.pem and key.pem")
    print(
        "Certificate covers: localhost, 127.0.0.1, " + ", ".join(lan_ips)
        + (f", {', '.join(extra_names)}" if extra_names else "")
    )
    if len(lan_ips) > 1:
        print(
            "(Found more than one LAN address on this machine -- covering all of"
            " them so the cert works no matter which one the phone actually reaches.)"
        )
    print("Valid for 10 years. Re-run this script if your LAN IP changes.")
    print()

    copied = _copy_to_pwa_folder()
    if copied:
        print(f"Copied cert.pem and key.pem into {copied}/ automatically.")
        print("Both servers are ready for HTTPS -- see HTTPS-SETUP.md to start them,")
        print("and run diagnose_network.py if a phone can't connect.")
    else:
        print("Next: copy cert.pem and key.pem into the price-checker-pwa folder too")
        print("(couldn't find it automatically -- see HTTPS-SETUP.md), then run")
        print("diagnose_network.py if a phone still can't connect.")


def _copy_to_pwa_folder():
    """Best-effort: if a price-checker-pwa folder sits next to this one (the
    normal layout when both project folders are unzipped side by side), copy
    the freshly generated cert/key there automatically so people don't forget
    this step -- a forgotten or stale copy is a common source of confusing
    per-server cert mismatches. Silently does nothing if it can't find one;
    the manual instructions in HTTPS-SETUP.md still work as a fallback."""
    import shutil
    from pathlib import Path

    here = Path(__file__).resolve().parent
    for candidate in here.parent.glob("*price-checker-pwa*"):
        if candidate.is_dir() and (candidate / "serve_https.py").exists():
            shutil.copy(here / "cert.pem", candidate / "cert.pem")
            shutil.copy(here / "key.pem", candidate / "key.pem")
            return candidate
    return None


if __name__ == "__main__":
    main()
