"""
generate_label.py
------------------
Injects product details (name, price/unit, barcode) pulled from the API
onto Longwan's real "HARGA BOOM" price tag template (assets/template_real.png).

Fonts are BUNDLED in assets/fonts/ (not loaded from the OS), so this renders
identically on Windows, Mac, or Linux:
  - Archivo Black          -> product name (Arial-Black-style heavy title)
  - Archivo (Bold Italic)  -> "RM" and "/ UNIT"
  - the big red price number also uses Archivo Black

Barcode is sized in real millimetres (not stretched to a fixed pixel width),
so a short code (e.g. "2300") renders compact and a long code renders wider --
exactly like a real barcode should, instead of a short code being blown up huge.

USAGE
-----
1. Edit API_URL / BRANCH_ID below if needed (confirmed contract:
   GET api.php?a=load_sku&keyword=<code>&branch_id=<id>)

2. Run:
     python generate_label.py --barcode 4800361382168
     python generate_label.py --sample        (uses bundled sample product, no API call)
     python generate_label.py --all-from-file LongWanProduct.txt   (batch, offline test)

3. Output PNGs land in ./output/.
"""
import argparse
import io
import json
import os

import requests
from PIL import Image, ImageDraw, ImageFont
from barcode import Code128
from barcode.writer import ImageWriter

# --- Patch a real data-loss bug in python-barcode's Code128 optimizer ---
# Its internal "TO" table maps a leading '99' digit-pair's code value (99) to
# 105, which happens to equal the plain START_C control code. The optimizer
# then collapses [START_C, 99] down to just [105], silently DELETING the '99'
# pair from the encoded barcode instead of producing a valid combined symbol.
# Any product/internal code starting with "99" would print a barcode that
# looks fine but decodes wrong or fails outright. Disabling this optimization
# only costs a couple of extra bars in the rare case it would've applied --
# it has zero effect on correctness otherwise. Confirmed via zxing-cpp /
# pyzbar cross-testing across dozens of codes before and after this patch.
Code128._try_to_optimize = lambda self, encoded: encoded

API_URL = "http://gmark.dyndns.org:3001/api.php"  # <-- point this at your real endpoint
BRANCH_ID = 3  # from Branch_List.txt (3#SP) -- change per branch this runs at
OUTPUT_DIR = "output"
TEMPLATE_PATH = "assets/template_real.png"
LABEL_DPI = 203  # Godex G500 native resolution -- keep barcode mm sizing tied to this

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_TITLE = os.path.join(HERE, "assets", "fonts", "ArchivoBlack-Regular.ttf")
FONT_ITALIC_VAR = os.path.join(HERE, "assets", "fonts", "Archivo-Italic-Variable.ttf")

# Content box measured from the real template (1118x795 source image).
# A custom background picked in the template editor is resized to this
# exact reference size before rendering, so box x/y/w/h below still line
# up regardless of the source image's own dimensions.
TEMPLATE_REF_SIZE = (1118, 795)


def _load_template_image(path):
    img = Image.open(path).convert("RGB")
    if img.size != TEMPLATE_REF_SIZE:
        img = img.resize(TEMPLATE_REF_SIZE, Image.LANCZOS)
    return img


# ============================================================================
# Freeform templates -- each named template (templates/<name>.json) is a
# background image + a list of boxes. Every visible thing on the tag,
# INCLUDING the product name/price/"RM"/unit/barcode, is just a box like any
# other -- there's no special-cased "fixed" element. Staff can drag any box
# around, resize it, restyle it, delete it, or add brand-new freeform text
# boxes (store name, a promo banner, whatever) -- all from the GUI's
# Template Editor, no code changes.
#
# Box shape (all keys optional except x/y/w/field -- missing ones fall back
# to sane defaults in the draw functions below, so a hand-edited or
# partially-written template JSON never crashes a render):
#   field: "name" | "price" | "rm" | "unit" | "barcode" | "promo_price" | "text"
#          (what content fills this box -- "text" = literal box["text"];
#          "promo_price" = typed in per print-run via the GUI's prompt,
#          never fetched from the API and never saved to disk)
#   text:  literal string, only used when field == "text"
#   x, y:  top-left corner, in 1118x795 reference-template pixels
#   w:     box width in pixels (text wraps to this; barcode is capped to it)
#   font:  "bold" (Archivo Black) | "italic" (Archivo Bold Italic)
#   font_size, color [R,G,B], align "left"|"center"|"right"
#   max_lines, line_spacing  (text boxes only)
#   module_width_px, module_height_mm, quiet_zone_mm, text_distance
#          (barcode box only -- real physical mm sizing, same as before)
# ============================================================================

TEMPLATES_DIR = os.path.join(HERE, "templates")
DEFAULT_TEMPLATE_NAME = "Default"

FIELD_CHOICES = [
    ("name", "Product name"),
    ("price", "Price number"),
    ("rm", '"RM" label'),
    ("unit", 'Unit (e.g. "/ UNIT")'),
    ("barcode", "Barcode"),
    ("promo_price", "Promotion price (manual)"),
    ("text", "Custom text"),
]
FONT_CHOICES = [
    ("bold", "Bold (Archivo Black)"),
    ("italic", "Bold Italic (Archivo)"),
]


def _default_template():
    """The exact original hardcoded layout, expressed as boxes. This is what
    ships as templates/Default.json the first time the tool runs, and is
    always available as a safety net (Duplicate it before experimenting)."""
    return {
        "name": DEFAULT_TEMPLATE_NAME,
        "background": "__default__",
        "boxes": [
            {
                "id": "name", "field": "name",
                "x": 90, "y": 230, "w": 975, "h": 130,
                "font": "bold", "font_size": 52, "color": [0, 0, 0],
                "align": "left", "max_lines": 2, "line_spacing": 62,
            },
            {
                "id": "rm", "field": "rm",
                "x": 90, "y": 448, "w": 160, "h": 80,
                "font": "italic", "font_size": 64, "color": [0, 0, 0],
                "align": "left", "max_lines": 1, "line_spacing": 70,
            },
            {
                "id": "price", "field": "price",
                "x": 280, "y": 328, "w": 620, "h": 200,
                "font": "bold", "font_size": 170, "color": [230, 20, 20],
                "align": "left", "max_lines": 1, "line_spacing": 190,
            },
            {
                "id": "unit", "field": "unit",
                "x": 90, "y": 530, "w": 975, "h": 60,
                "font": "italic", "font_size": 50, "color": [0, 0, 0],
                "align": "right", "max_lines": 1, "line_spacing": 55,
            },
            {
                "id": "barcode", "field": "barcode",
                "x": 90, "y": 600, "w": 975, "h": 135,
                "align": "right", "edge_margin_px": 50,
                "module_width_px": 3, "module_width_px_fallback": 2,
                "module_height_mm": 13, "quiet_zone_mm": 2.5,
                "font_size": 8, "text_distance": 3,
            },
        ],
    }


def _safe_filename(name):
    keep = " -_()"
    cleaned = "".join(c for c in name if c.isalnum() or c in keep).strip()
    return cleaned or "template"


def _template_path(name):
    return os.path.join(TEMPLATES_DIR, f"{_safe_filename(name)}.json")


def list_templates():
    """Names of every saved template, always including the built-in Default
    (writing it to disk on first run if it isn't there yet)."""
    os.makedirs(TEMPLATES_DIR, exist_ok=True)
    names = sorted(
        os.path.splitext(f)[0] for f in os.listdir(TEMPLATES_DIR) if f.lower().endswith(".json")
    )
    if DEFAULT_TEMPLATE_NAME not in names:
        save_template(_default_template())
        names = sorted(names + [DEFAULT_TEMPLATE_NAME])
    return names


def load_template(name):
    path = _template_path(name)
    if not os.path.exists(path):
        if name == DEFAULT_TEMPLATE_NAME:
            tpl = _default_template()
            save_template(tpl)
            return tpl
        raise FileNotFoundError(f"No such template: {name}")
    with open(path, "r", encoding="utf-8") as f:
        tpl = json.load(f)
    tpl.setdefault("name", name)
    tpl.setdefault("boxes", [])
    return tpl


def save_template(template):
    os.makedirs(TEMPLATES_DIR, exist_ok=True)
    with open(_template_path(template["name"]), "w", encoding="utf-8") as f:
        json.dump(template, f, indent=2)
    return _template_path(template["name"])


def delete_template(name):
    path = _template_path(name)
    if os.path.exists(path):
        os.remove(path)


def rename_template(old_name, new_name):
    tpl = load_template(old_name)
    tpl["name"] = new_name
    save_template(tpl)
    if old_name != new_name:
        delete_template(old_name)


def template_uses_field(template, field):
    """True if any box in the template is bound to the given field -- used
    to decide whether printing with this template needs a manual prompt
    first (e.g. a promo-price box, which can't come from the product API)."""
    return any(b.get("field") == field for b in template.get("boxes", []))


def _resolve_background_path(background):
    if not background or background == "__default__":
        return os.path.join(HERE, TEMPLATE_PATH)
    if os.path.isabs(background):
        return background
    return os.path.join(HERE, background)


# --- active template (which named template new labels render with) -------
_active_template_name = DEFAULT_TEMPLATE_NAME
_active_template_cache = None


def set_active_template_name(name):
    global _active_template_name, _active_template_cache
    _active_template_name = name or DEFAULT_TEMPLATE_NAME
    _active_template_cache = None  # force reload next get_active_template()


def get_active_template_name():
    return _active_template_name


def get_active_template():
    """The currently active template dict, loaded from disk once and cached
    until set_active_template_name() (a switch) or reload_active_template()
    (an in-place edit was saved) invalidates it."""
    global _active_template_cache
    if _active_template_cache is None:
        try:
            _active_template_cache = load_template(_active_template_name)
        except FileNotFoundError:
            _active_template_cache = load_template(DEFAULT_TEMPLATE_NAME)
    return _active_template_cache


def reload_active_template():
    global _active_template_cache
    _active_template_cache = None
    return get_active_template()


def _title_font(size):
    return ImageFont.truetype(FONT_TITLE, size)


def _bold_italic_font(size):
    f = ImageFont.truetype(FONT_ITALIC_VAR, size)
    try:
        f.set_variation_by_name("Bold Italic")
    except Exception:
        pass  # static fallback build of the font, already italic
    return f


def _wrap_text(draw, text, font, max_width):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=font) <= max_width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def make_barcode_image(
    code_value,
    module_width_px=3,
    module_height_mm=13,
    quiet_zone_mm=2.5,
    font_size=8,
    text_distance=3,
    dpi=None,
    write_text=True,
):
    """
    Render at real physical mm size (tied to `dpi`), with the module width
    chosen to land on an exact whole pixel count at that dpi.

    `dpi` defaults to LABEL_DPI (the Godex thermal printer's native 203dpi),
    which is what every direct-to-label caller wants. Pass a different dpi
    (e.g. make_a4_sheet.py passing 300, the A4 sheet's own dpi) to render a
    barcode natively at the resolution it will actually be printed at --
    this is the ONLY correct way to change a barcode's printed size. Never
    take the bitmap this function returns and resize/resample it afterward;
    that reintroduces fractional-pixel blur and silently degrades module
    width below what the module_width_px/dpi math promises (this is exactly
    what caused make_a4_sheet.py's 4-per-row scan failures -- see its
    module docstring).

    All sizing comes from the barcode box's own settings in the active
    template (compose_label passes the fallback module width explicitly when
    the primary width renders wider than the box) -- no global style lookup.

    `write_text=False` renders bars only. python-barcode sizes its own
    canvas from the module count alone and never widens it to fit the
    human-readable text it draws underneath -- at a small font that's
    invisible, but at a font big enough to actually read, the text is
    wider than the bars and just gets clipped off both edges of that
    narrow canvas. `_draw_barcode_box` renders bars-only here and draws the
    human-readable number itself, at whatever size/width the label
    actually needs, instead of relying on python-barcode's own text.

    IMPORTANT: options MUST be passed via write(..., options={...}), not via
    writer.set_options() beforehand. Code128.render() (in python-barcode)
    rebuilds its options dict from scratch and only merges in whatever was
    passed to write()/render() -- a pre-configured writer's settings for
    module_width/quiet_zone get silently discarded and replaced with the
    library's internal MIN_SIZE/MIN_QUIET_ZONE defaults. This was the actual
    cause of the scan failures: every barcode was being rendered at those
    tiny hardcoded defaults regardless of what we asked for, and rounding
    error at that scale corrupted bar widths for certain digit sequences.
    """
    dpi = dpi or LABEL_DPI
    module_width_mm = module_width_px * 25.4 / dpi
    options = {
        "module_width": module_width_mm,
        "module_height": module_height_mm,  # mm -- taller bars are more scan-tolerant
        "quiet_zone": quiet_zone_mm,         # mm -- safely above the >=10x module minimum
        "font_size": font_size,
        "text_distance": text_distance,
        "dpi": dpi,
        "write_text": write_text,
    }
    buf = io.BytesIO()
    writer = ImageWriter()
    Code128(code_value, writer=writer).write(buf, options=options)
    buf.seek(0)
    return Image.open(buf).convert("RGB")


def barcode_selftest(code_value, bc_img):
    """
    Decode our own generated barcode before it ever reaches the printer.
    Catches encoding/sizing problems immediately instead of finding out
    after a physical print.

    This is a nice-to-have safety check, not a hard requirement -- if the
    underlying zbar native library can't load (missing on this machine, or
    missing its own dependency like the VC++ runtime on Windows), that
    surfaces as OSError/FileNotFoundError, not ImportError. Catching only
    ImportError here used to let that escape and take the whole label render
    down with it. Skip the self-test instead; the barcode itself still gets
    generated and printed fine, it just isn't independently re-verified.
    """
    try:
        from pyzbar.pyzbar import decode as zbar_decode
    except ImportError:
        return None  # pyzbar not installed -- skip silently, not fatal
    except OSError:
        return None  # zbar native lib (or a dependency) failed to load -- skip silently
    try:
        results = zbar_decode(bc_img)
    except OSError:
        return None
    ok = any(r.data.decode("utf-8", "ignore") == str(code_value) for r in results)
    return ok


def _box_content(box, product):
    """The string this box should render, based on its field binding.
    field == "text" is a fully custom freeform box -- its content is
    whatever literal text was typed into the template editor, the same for
    every label (e.g. a store name or promo banner), not pulled from the
    product at all."""
    field = box.get("field", "text")
    if field == "name":
        return (product.get("description") or "").strip()
    if field == "price":
        price = product.get("price", "0.00")
        try:
            return f"{float(price):.2f}"
        except (TypeError, ValueError):
            # Bad/blank price from the API shouldn't take down the whole
            # render -- show it plainly so the problem is obvious on the
            # printed tag itself instead of silently failing the batch.
            return str(price) if price not in (None, "") else "0.00"
    if field == "rm":
        return "RM"
    if field == "unit":
        uom = (product.get("uom") or "UNIT").upper()
        return f"/ {uom}"
    if field == "barcode":
        return product.get("scan_code") or product.get("barcode") or ""
    if field == "promo_price":
        # Set per print-run by the GUI's Promotion price prompt (never
        # comes from the API, never saved into the template/product data
        # on disk) -- see gui.PromoPriceWindow. Blank here means no run is
        # in progress (e.g. the Template Editor's live sample preview),
        # not a missing/blank promo -- the GUI enforces non-blank before
        # a real print job is allowed to proceed.
        return (product.get("_promo_price") or "").strip()
    return box.get("text", "")  # field == "text"


def _box_font(box):
    size = box.get("font_size", 40)
    return _bold_italic_font(size) if box.get("font") == "italic" else _title_font(size)


def _draw_text_box(draw, box, text):
    if not text:
        return
    font = _box_font(box)
    color = tuple(box.get("color", [0, 0, 0]))
    align = box.get("align", "left")
    max_lines = max(1, box.get("max_lines", 1))
    line_spacing = box.get("line_spacing", box.get("font_size", 40) + 12)
    x, y, w = box.get("x", 0), box.get("y", 0), max(1, box.get("w", 400))

    lines = _wrap_text(draw, text, font, w)[:max_lines]
    cy = y
    for line in lines:
        line_w = draw.textlength(line, font=font)
        if align == "center":
            lx = x + (w - line_w) / 2
        elif align == "right":
            lx = x + (w - line_w)
        else:
            lx = x
        draw.text((lx, cy), line, font=font, fill=color)
        cy += line_spacing


def _draw_barcode_box(img, box, product):
    code_value = product.get("scan_code") or product.get("barcode") or ""
    if not code_value:
        return
    x, y, w = box.get("x", 0), box.get("y", 0), max(1, box.get("w", 400))

    # The barcode box's own w/h were sized close to the template's printed
    # border artwork (the barcode sits at the bottom-right of the tag, right
    # next to the border line). The barcode PNG's built-in quiet zone is
    # whitespace, not transparency, so if it's allowed to fill the box all
    # the way to w/h it visibly paints over -- "covers" -- that border line
    # instead of sitting inside it. edge_margin_px reserves a strip on the
    # box's trailing edges (right, for align="right"/"center"; bottom,
    # always) that the rendered barcode must stay clear of, so there's
    # always a visible gap between the barcode and the border next to it.
    edge_margin_px = max(0, box.get("edge_margin_px", 50))
    fit_w = max(1, w - edge_margin_px)

    # Height budget: measured from the box's own top edge down to the
    # template's REAL printed border (img.height - y), not the box's
    # static "h" field. "h" is just a nominal layout value the Template
    # Editor draws a drag-handle around -- on the Default template it's
    # 135px, but the actual clear white space above the border artwork
    # below it is ~155px (confirmed by sampling the template PNG). Using
    # the smaller "h" as the fit budget used to force this function to
    # shrink the barcode -- and, worse, the human-readable number printed
    # under it -- far more aggressively than the template artwork actually
    # requires, crushing the digits down to an unreadable font size. This
    # mirrors the fix already applied on the A4-sheet path (make_a4_sheet.py's
    # _recrisp_barcode uses `fitted_h - box_y`, the label's real remaining
    # height, for exactly this reason) -- this brings the single-label path
    # in line with it.
    available_h = max(1, img.height - y)
    fit_h = max(1, available_h - edge_margin_px)

    module_width_px = box.get("module_width_px", 3)
    module_height_mm = box.get("module_height_mm", 9)
    quiet_zone_mm = box.get("quiet_zone_mm", 2.5)
    # Human-readable number is drawn ourselves (see make_barcode_image's
    # write_text=False docstring for why), in the same px-size convention
    # as every other text box on the label -- number_font_size defaults to
    # roughly the size of the "/ BOX" unit text (font_size 50 on the
    # Default template) so it reads at a glance, not a tiny caption.
    number_font_size = box.get("number_font_size", 46)
    number_gap_px = max(0, box.get("number_gap_px", 10))
    # Floor so the shrink loop below sacrifices bar height, not number
    # legibility, when the box is tight.
    min_number_font_size = box.get("min_number_font_size", 24)
    min_module_height_mm = box.get("min_module_height_mm", 3.0)

    bc_img = make_barcode_image(
        code_value,
        module_width_px=module_width_px,
        module_height_mm=module_height_mm,
        quiet_zone_mm=quiet_zone_mm,
        write_text=False,
    )
    # Real mm size, never resized (resizing reintroduces the fractional-pixel
    # blur that caused scan failures). If it doesn't fit the box width
    # (minus edge_margin_px), shrink by regenerating at a smaller module
    # width -- never by stretching pixels of an already-built image.
    if bc_img.width > fit_w:
        module_width_px = box.get("module_width_px_fallback", 2)
        bc_img = make_barcode_image(
            code_value,
            module_width_px=module_width_px,
            module_height_mm=module_height_mm,
            quiet_zone_mm=quiet_zone_mm,
            write_text=False,
        )

    number_font = _title_font(number_font_size)
    draw = ImageDraw.Draw(img)
    number_w = draw.textlength(code_value, font=number_font)

    # Shrink to fit the available height: bars + gap + number must all fit
    # in fit_h. Bar height comes down first; the number only shrinks once
    # module_height_mm has already hit its own floor, so a tight box
    # sacrifices bar height before it sacrifices whether a retail
    # assistant can actually read the digits off the tag.
    for _ in range(6):
        total_h = bc_img.height + number_gap_px + number_font_size
        if total_h <= fit_h:
            break
        if module_height_mm > min_module_height_mm:
            module_height_mm = max(min_module_height_mm, module_height_mm * 0.85)
            bc_img = make_barcode_image(
                code_value,
                module_width_px=module_width_px,
                module_height_mm=module_height_mm,
                quiet_zone_mm=quiet_zone_mm,
                write_text=False,
            )
        elif number_font_size > min_number_font_size:
            number_font_size = max(min_number_font_size, round(number_font_size * 0.9))
            number_font = _title_font(number_font_size)
            number_w = draw.textlength(code_value, font=number_font)
        else:
            break

    # Width check for the number: python-barcode's bars stay narrow even
    # for long codes, but a 13-digit EAN at a large font can still run
    # wider than fit_w -- shrink the number's own font (never the bars)
    # until it fits, rather than let it run into the border margin.
    while number_w > fit_w and number_font_size > 12:
        number_font_size -= 2
        number_font = _title_font(number_font_size)
        number_w = draw.textlength(code_value, font=number_font)

    if bc_img.height + number_gap_px + number_font_size > fit_h:
        print(
            f"  WARNING: barcode+number for '{code_value}' is taller "
            f"({bc_img.height + number_gap_px + number_font_size}px) than the "
            f"space available above the border ({fit_h}px) even after "
            f"shrinking -- check this label before printing."
        )

    ok = barcode_selftest(code_value, bc_img)
    if ok is False:
        print(f"  WARNING: barcode self-test FAILED to decode for code '{code_value}' -- check this label before printing.")

    # Positioning uses fit_w (= w - edge_margin_px), not the raw box w, so
    # align="right"/"center" leave edge_margin_px of clear whitespace-free
    # gap between the barcode and the box's right edge (where the border
    # artwork sits) instead of pushing the barcode flush against it.
    align = box.get("align", "left")
    if align == "right":
        bx = x + max(0, fit_w - bc_img.width)
    elif align == "center":
        bx = x + max(0, (fit_w - bc_img.width) // 2)
    else:
        bx = x
    img.paste(bc_img, (bx, y))

    # Human-readable number: centered under the bars themselves (standard
    # barcode-label convention), not the wider box -- same color/font
    # family as the rest of the label, drawn with a plain draw.text call
    # (no wrapping needed, it's one line of digits).
    number_color = tuple(box.get("number_color", [0, 0, 0]))
    ny = y + bc_img.height + number_gap_px
    nx = bx + max(0, (bc_img.width - number_w) / 2)
    draw.text((nx, ny), code_value, font=number_font, fill=number_color)



def compose_label(product, template=None):
    """
    product: dict with keys like description, price, uom, barcode/scan_code
             (same shape as items in LongWanProduct.txt)
    template: optional template dict (background + boxes, see the "Freeform
    templates" block above) to render with instead of the currently active
    one. Lets a caller (e.g. the Template Editor) preview edits live without
    saving the template file first.
    """
    template = template or get_active_template()
    img = _load_template_image(_resolve_background_path(template.get("background")))
    draw = ImageDraw.Draw(img)

    for box in template.get("boxes", []):
        if box.get("field") == "barcode":
            _draw_barcode_box(img, box, product)
        else:
            _draw_text_box(draw, box, _box_content(box, product))

    return img


def fetch_product_by_barcode(barcode):
    """
    Confirmed from a live traffic capture of the old exe:
    GET api.php?a=load_sku&keyword=<code>&branch_id=<id>
    (param is "keyword", NOT "barcode")
    """
    resp = requests.get(
        API_URL,
        params={"a": "load_sku", "keyword": barcode, "branch_id": BRANCH_ID},
        timeout=5,
    )
    resp.raise_for_status()
    data = resp.json()
    if isinstance(data, dict) and data.get("status") == 0:
        raise RuntimeError(f"API error for barcode {barcode}: {data.get('msg')}")
    return data


SAMPLE_PRODUCT = {
    "description": "COLGATE NATURAL PURE CLEAN CHARCOAL 120G",
    "price": "6.99",
    "uom": "UNIT",
    "barcode": "4800361382168",
    "scan_code": "0215661010006",
}

# Per-template sample overrides for preview purposes (home screen cards,
# the Settings sidebar preview, and the Template Editor's live preview).
# Most templates are happy with the generic SAMPLE_PRODUCT above, but a
# template like Promotion has boxes bound to fields the generic sample
# doesn't carry (promo_price is normally only ever set per print-run via
# the GUI's PromoPriceWindow prompt -- see _box_content) -- without an
# override those boxes would preview blank/empty instead of showing what
# a real promo tag looks like.
SAMPLE_PRODUCTS_BY_TEMPLATE = {
    "Promotion": {
        "description": "NOVA ACTIVMAX CEREAL BREAKFAST 850GM",
        "price": "95.59",
        "uom": "UNIT",
        "barcode": "9556001112223",
        "scan_code": "9556001112223",
        "_promo_price": "81.89",
    },
}


def get_sample_product(template_name=None):
    """Sample product dict to preview `template_name` with -- the generic
    SAMPLE_PRODUCT, merged with a template-specific override if one is
    registered in SAMPLE_PRODUCTS_BY_TEMPLATE above."""
    override = SAMPLE_PRODUCTS_BY_TEMPLATE.get(template_name or "")
    if not override:
        return SAMPLE_PRODUCT
    product = dict(SAMPLE_PRODUCT)
    product.update(override)
    return product


def load_codes_from_list_files(paths):
    """
    Read one or more plain text files (one scanned code per line -- exactly
    what an OTG barcode scanner types into a phone notes/text app, one line
    per Enter keystroke). Multiple files let you keep scans separated by
    gondola/aisle (gondola1.txt, gondola2.txt, ...) while still generating
    every label together in a single run/print pass.
    Blank lines are skipped. Duplicate codes across files are de-duplicated
    (first occurrence wins) so re-scanning the same item twice doesn't print
    it twice.
    """
    codes = []
    for path in paths:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                code = line.strip()
                if code:
                    codes.append(code)
    seen = set()
    unique_codes = []
    for c in codes:
        if c not in seen:
            seen.add(c)
            unique_codes.append(c)
    skipped = len(codes) - len(unique_codes)
    if skipped:
        print(f"Note: {skipped} duplicate scanned code(s) skipped.")
    return unique_codes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--barcode", help="Fetch a single product from the API by barcode")
    parser.add_argument("--sample", action="store_true", help="Render the bundled sample product (no API call)")
    parser.add_argument("--all-from-file", help="Batch-render every item in a LongWanProduct.txt-style JSON file")
    parser.add_argument(
        "--barcode-list",
        nargs="+",
        metavar="FILE",
        help=(
            "One or more plain text files, each with one scanned code per line "
            "(e.g. gondola1.txt gondola2.txt synced from a phone's notes app "
            "after OTG-scanning a batch). Looks up every code via the API and "
            "generates all labels from all files together in this single run."
        ),
    )
    args = parser.parse_args()

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    products = []
    if args.sample:
        products = [SAMPLE_PRODUCT]
    elif args.barcode:
        doc = fetch_product_by_barcode(args.barcode)
        items = doc.get("items", [])
        if not items:
            print(f"No items returned for barcode {args.barcode}. Raw response: {doc}")
            return
        products = items
    elif args.all_from_file:
        with open(args.all_from_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        products = data.get("items", [])
    elif args.barcode_list:
        codes = load_codes_from_list_files(args.barcode_list)
        print(f"Looking up {len(codes)} scanned code(s)...")
        for code in codes:
            try:
                doc = fetch_product_by_barcode(code)
                items = doc.get("items", [])
                if not items:
                    print(f"  WARNING: no product found for scanned code '{code}' -- skipping.")
                    continue
                products.extend(items)
            except Exception as e:
                print(f"  WARNING: failed to fetch '{code}': {e} -- skipping.")
    else:
        parser.print_help()
        return

    for p in products:
        img = compose_label(p)
        safe_code = (p.get("scan_code") or p.get("barcode") or "label").replace("/", "_")
        out_path = os.path.join(OUTPUT_DIR, f"{safe_code}.png")
        img.save(out_path)
        print(f"Saved {out_path}")


if __name__ == "__main__":
    main()
