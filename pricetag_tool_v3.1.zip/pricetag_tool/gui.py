"""
gui.py -- desktop front-end for the Longwan price tag generator.

Scan (or type) a barcode, hit Enter -> looks the product up via the store
API and adds a row with a checkbox. Tick the rows you want, then:

  - Print   -> renders the ticked labels, tiles them 12-up onto A4 page(s),
               and shows a PREVIEW window before anything is sent to the
               printer. Confirm there to actually print.
  - Remove  -> deletes the ticked rows from the list (the rest stay)
  - Clear   -> empties the whole list

Run:
    python gui.py
"""
import csv
import hashlib
import json
import os
import threading
import traceback
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from tkinter import colorchooser, filedialog, ttk, messagebox

from PIL import Image, ImageTk

import generate_label
from generate_label import (
    compose_label,
    fetch_product_by_barcode,
    load_codes_from_list_files,
    OUTPUT_DIR,
)
from make_a4_sheet import build_pages, PAGE_W_MM, PAGE_H_MM, VALID_COLS, DEFAULT_COLS, ROWS as A4_ROWS
from flag_server import FlagQueue, run_server_in_thread, DEFAULT_PORT as FLAG_SERVER_PORT, is_https_enabled
from netinfo import list_lan_ips

try:
    import qrcode
except ImportError:
    qrcode = None

MIN_TAGS_NO_CONFIRM = 4  # printing fewer price tags than this asks for confirmation first
MAX_FETCH_WORKERS = 6  # concurrent API lookups for batch barcode-file loads
MAX_RENDER_WORKERS = 6  # concurrent label composition threads when printing

# ---- "CSS" for Tk: one palette + one ttk.Style setup, applied once at startup.
# Tkinter has no stylesheets, but ttk.Style's named styles work the same way --
# define a look once (colors/fonts/padding/hover state), then reference it by
# name on any widget (style="Primary.TButton" etc.) instead of hand-styling
# each one individually.
PALETTE = {
    "bg": "#F5F6F8",  # app background
    "surface": "#FFFFFF",  # cards / sidebar / row background
    "row_alt": "#F0F2F5",  # zebra-stripe alternate row
    "border": "#E1E4E8",
    "text": "#1F2328",
    "muted": "#6B7280",
    "primary": "#2563EB",  # Add / Print
    "primary_hover": "#1D4ED8",
    "primary_press": "#1E40AF",
    "danger": "#DC2626",  # Remove / Clear
    "danger_hover": "#B91C1C",
    "danger_press": "#991B1B",
    "accent_text": "#FFFFFF",
}
FONT_BASE = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_HEADER = ("Segoe UI", 11, "bold")

HERE = os.path.dirname(os.path.abspath(__file__))
ICON_PATH = os.path.join(HERE, "assets", "icon.ico")
SETTINGS_PATH = os.path.join(HERE, "settings.json")


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return {}


def save_settings(settings):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=2)
    except OSError:
        pass  # non-fatal -- the choice just won't be remembered next launch


def list_printers():
    """
    (names, default_name) of installed Windows printers, via pywin32.
    Returns ([], None) on any non-Windows machine, or if pywin32 isn't
    installed here -- callers fall back to "(no printers found)" instead
    of crashing. This used to be called with neither an import nor a
    definition anywhere in the project, which -- since the app launches via
    pythonw.exe (no console window) -- meant the whole GUI died silently on
    startup with no visible error at all.
    """
    try:
        import win32print
    except ImportError:
        return [], None
    try:
        default = win32print.GetDefaultPrinter()
    except Exception:
        default = None
    try:
        flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
        names = [p[2] for p in win32print.EnumPrinters(flags, None, 1)]
    except Exception:
        names = []
    return names, default


def print_pages_gdi(pages, printer_name=None):
    """
    Print already-rendered PIL Image pages directly to a Windows printer via
    GDI (win32ui device context + PIL's ImageWin.Dib), bypassing PDF/file
    associations entirely -- each page is drawn straight onto the printer's
    device context as a bitmap, the same low-level path any Windows
    image-printing app uses. This sidesteps ShellExecute's dependency on a
    registered PDF "print" verb, which is the actual root cause behind the
    repeated (31, 'ShellExecute', 'A device attached to the system is not
    functioning.') failures -- that error means Windows can't find/invoke a
    handler for the verb, not that anything is wrong with the printer
    itself. Since a PDF was never required for this to work (the pages
    already exist as PIL Images before they're ever saved to disk), this is
    the more reliable primary path; print_pages() below is kept only as a
    fallback for machines where this GDI path itself fails.
    """
    import win32print
    import win32ui
    import win32con
    from PIL import ImageWin

    if not printer_name:
        printer_name = win32print.GetDefaultPrinter()
    if not printer_name:
        raise RuntimeError(
            "No printer available -- no printer was picked in the app and no "
            "default printer is set in Windows."
        )

    hdc = win32ui.CreateDC()
    hdc.CreatePrinterDC(printer_name)
    try:
        hdc.StartDoc("Longwan Price Tags")
        printable_w = hdc.GetDeviceCaps(win32con.HORZRES)
        printable_h = hdc.GetDeviceCaps(win32con.VERTRES)

        for page in pages:
            hdc.StartPage()
            # Fit the (already A4-shaped) page image into the printer's
            # actual printable area, preserving aspect ratio and centering
            # -- printable area is usually slightly smaller than the full
            # paper size because of the printer's own hardware margins.
            scale = min(printable_w / page.width, printable_h / page.height)
            w = max(1, round(page.width * scale))
            h = max(1, round(page.height * scale))
            x = (printable_w - w) // 2
            y = (printable_h - h) // 2

            dib = ImageWin.Dib(page)
            dib.draw(hdc.GetHandleOutput(), (x, y, x + w, y + h))
            hdc.EndPage()

        hdc.EndDoc()
    finally:
        hdc.DeleteDC()


def _default_printer_name():
    """Best-effort read of the OS default printer, or None if there isn't
    one / pywin32 can't tell us. Used only to annotate a print failure with
    a likely cause -- never to block the print attempt itself, since a
    missing/unreadable default doesn't necessarily mean printing will fail
    (a printer_name may still be explicitly passed in)."""
    try:
        import win32print
        return win32print.GetDefaultPrinter()
    except Exception:
        return None


def _has_pdf_print_handler():
    """Best-effort check for a classic registry-registered PDF 'print' verb
    (what Adobe Reader/SumatraPDF/etc. register). Diagnostic only -- modern
    PDF handlers (Edge, and some other UWP/MSIX-packaged viewers) don't
    necessarily register this the old-fashioned way, but ShellExecute's
    "print" verb can still work against them via the OS's app-registration
    layer. A False here does NOT mean printing will fail -- it's only used
    to suggest a likely cause when a print attempt has already failed."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r".pdf") as key:
            prog_id = winreg.QueryValue(key, None)
        if not prog_id:
            return False
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, fr"{prog_id}\shell\print"):
            pass
        return True
    except Exception:
        return False


def print_pages(pages, pdf_path, printer_name=None):
    """
    Send the already-rendered A4 pages (saved at pdf_path) to a printer.
    Windows-only: shells out to the "printto"/"print" verb on the PDF --
    the same thing Explorer's right-click > Print does -- so it goes
    through whatever PDF handler and printer driver/paper-size settings are
    already configured on this PC, instead of hand-building a raw print job
    for a multi-page tiled PDF.

    IMPORTANT: this is called from a background thread (see
    PriceTagApp._confirm_and_print), and ShellExecute's print/printto verbs
    route through COM for many file-type handlers -- exactly what Explorer's
    right-click > Print does under the hood. A thread that hasn't
    initialized a COM apartment gets a generic, misleading failure for this
    ("(31, 'ShellExecute', 'A device attached to the system is not
    functioning.')") that has nothing to do with the actual printer.
    pythoncom.CoInitialize()/CoUninitialize() bracket the call so this
    thread has its own apartment, matching what already happens implicitly
    on the main thread.

    NOTE: the exact same error code also fires for a couple of unrelated
    causes (no default printer configured, no PDF print handler
    registered) -- but those are only DIAGNOSED after a real failure below,
    never pre-checked/blocked ahead of time. Some working setups (e.g.
    printing successfully via Edge as the default PDF viewer) won't
    register a PDF print handler the classic way _has_pdf_print_handler()
    looks for, so treating that check as a hard gate would incorrectly
    block printing that actually works fine.
    """
    try:
        import win32api
        import pythoncom
    except ImportError:
        raise RuntimeError(
            "Direct printing needs pywin32, which isn't available on this machine "
            "(this feature is Windows-only)."
        )

    pythoncom.CoInitialize()
    try:
        if printer_name:
            win32api.ShellExecute(0, "printto", pdf_path, f'"{printer_name}"', ".", 0)
        else:
            win32api.ShellExecute(0, "print", pdf_path, None, ".", 0)
    except Exception as e:
        # Print attempt genuinely failed -- now (and only now) run the
        # diagnostics, to suggest a likely cause in the error we raise.
        hints = []
        if not printer_name and not _default_printer_name():
            hints.append(
                "no default printer is set in Windows and none was picked in the app"
            )
        if not _has_pdf_print_handler():
            hints.append(
                "no classic PDF 'print' handler is registered for .pdf files "
                "(some viewers, including some Edge configurations, don't "
                "register one even though direct printing may still work)"
            )
        if hints:
            raise RuntimeError(f"{e}\n\nPossible cause(s): {'; '.join(hints)}.") from e
        raise
    finally:
        pythoncom.CoUninitialize()


class PriceTagApp:
    # These are *target* sizes -- _place_window() below clamps them to
    # whatever screen the app is actually running on and centers the
    # result, so a small/laptop display never ends up with part (or all)
    # of the window positioned off-screen and invisible.
    HOME_SIZE = (880, 720)
    HOME_MINSIZE = (680, 560)
    APP_SIZE = (960, 540)
    APP_MINSIZE = (760, 400)

    def __init__(self, root):
        self.root = root
        root.title("Longwan Price Tag Printer")
        self._place_window(*self.HOME_SIZE, *self.HOME_MINSIZE)
        self._apply_style()
        self._set_window_icon()

        # each entry: {"product": dict, "var": tk.BooleanVar, "frame": ttk.Frame}
        self.items = []

        self.printer_var = tk.StringVar(value="")
        self.settings = load_settings()

        # --- Price Checker PWA intake -------------------------------------
        # Staff on the retail floor use a phone PWA to scan a barcode, look
        # the price up via the same api.php the tool itself uses, and flag
        # it here if the printed shelf tag doesn't match. Those flags land
        # in this queue over the LAN (nothing leaves the local network) and
        # show up as a badge on the "Price Flags" button for review.
        self.flag_queue = FlagQueue()
        flag_port = self.settings.get("flag_server_port", FLAG_SERVER_PORT)
        try:
            run_server_in_thread(self.flag_queue, generate_label.BRANCH_ID, port=flag_port)
            self.flag_server_port = flag_port
        except Exception as e:
            # Don't let a port conflict or missing Flask dependency take the
            # whole desktop app down -- the tool still works without it,
            # just without phone intake for this session.
            self.flag_server_port = None
            print(f"WARNING: could not start price-flag server: {e}")

        # Tags-per-row for the A4 sheet layout (2/3/4) -- remembered across
        # sessions the same way the printer/template choices are.
        saved_cols = self.settings.get("tags_per_row", DEFAULT_COLS)
        if saved_cols not in VALID_COLS:
            saved_cols = DEFAULT_COLS
        self.cols_var = tk.IntVar(value=saved_cols)
        self.settings_visible = False
        self._template_thumb = None  # keep a ref so Tk doesn't garbage-collect it
        self._home_card_thumbs = {}  # same, for the home-screen template cards
        # Composed label PNGs, keyed by a hash of (template + product +
        # promo price) -- see _label_cache_key(). Lets re-printing a batch
        # that hasn't actually changed (e.g. Cancel out of Preview, tweak
        # nothing, hit Print again) skip re-composing/re-rendering every
        # label from scratch. Automatically invalidated per-item whenever
        # its price/promo/description or the active template's own design
        # changes, since any of those changes the hash.
        self._label_render_cache = {}

        # One shared, bounded pool for every barcode lookup -- both a live
        # scan at the entry box and a batch file load submit into this same
        # pool instead of each spawning its own raw thread. Caps how many
        # lookups are ever in flight at once (MAX_FETCH_WORKERS) regardless
        # of how fast codes come in, so a gondola scanner firing several
        # codes a second queues the overflow instead of opening a new
        # connection to the API per scan -- see _on_add_barcode.
        self._fetch_executor = ThreadPoolExecutor(max_workers=MAX_FETCH_WORKERS)
        # Codes currently mid-lookup (submitted but not yet added as a row)
        # -- guards a fast double-scan (or a mis-scan that fires twice)
        # from queuing two lookups for the same code before the first one
        # has landed and become visible in self.items.
        self._pending_codes = set()
        self._pending_lock = threading.Lock()

        self.root.protocol("WM_DELETE_WINDOW", self._on_app_close)

        # {barcode: last-entered promo price text}, persisted in settings.json
        # so a barcode's promo price doesn't need retyping next print run --
        # promotions don't change often. Populated/edited via PromoPriceWindow.
        self.promo_price_cache = self.settings.get("promo_price_cache", {})

        # apply whichever named template was active last session, if it still exists
        saved_template_name = self.settings.get("active_template")
        if saved_template_name and saved_template_name in generate_label.list_templates():
            generate_label.set_active_template_name(saved_template_name)
        else:
            generate_label.set_active_template_name(generate_label.DEFAULT_TEMPLATE_NAME)

        # -- Home (landing) screen: shown first, on top of everything else.
        # The scan/print workflow below lives in its own container frame so
        # it can be swapped in with one pack() once the user hits Continue.
        self.home_frame = ttk.Frame(self.root, padding=(20, 16, 20, 16))
        self._build_home_screen(self.home_frame)

        self.app_container = ttk.Frame(self.root)
        self._build_top_bar()
        self._build_printer_bar()
        self._build_main_area()
        self._build_bottom_bar()

        self._flags_window = None
        self._poll_flags()

        self._show_home()

    def _apply_style(self):
        """One-time theme setup -- the Tk equivalent of loading a stylesheet."""
        p = PALETTE
        self.root.configure(bg=p["bg"])

        style = ttk.Style(self.root)
        # "clam" is the only built-in theme that actually honors custom
        # colors on buttons/frames cross-platform; the default Windows
        # theme ignores most background/foreground overrides.
        style.theme_use("clam")

        style.configure(".", background=p["bg"], foreground=p["text"], font=FONT_BASE)
        style.configure("TFrame", background=p["bg"])
        style.configure("TLabel", background=p["bg"], foreground=p["text"])
        style.configure("Header.TLabel", font=FONT_HEADER, background=p["bg"])
        style.configure("Muted.TLabel", foreground=p["muted"], background=p["bg"])
        style.configure("Bold.TLabel", font=FONT_BOLD, background=p["bg"])

        style.configure(
            "TEntry",
            fieldbackground=p["surface"],
            bordercolor=p["border"],
            lightcolor=p["border"],
            darkcolor=p["border"],
            padding=6,
        )
        # Highlight state for a required field left blank (e.g. the
        # Promotion price prompt) -- same as TEntry but a red border, so a
        # missing value is obvious without a popup alone.
        style.configure(
            "Invalid.TEntry",
            fieldbackground=p["surface"],
            bordercolor=p["danger"],
            lightcolor=p["danger"],
            darkcolor=p["danger"],
            padding=6,
        )
        style.configure(
            "TCombobox",
            fieldbackground=p["surface"],
            background=p["surface"],
            padding=4,
        )
        style.configure("TSeparator", background=p["border"])
        style.configure("TCheckbutton", background=p["bg"])

        # -- Home screen "card" panels: white surface with a thin border,
        # standing out from the plain app background behind them.
        style.configure(
            "Card.TFrame",
            background=p["surface"],
            bordercolor=p["border"],
            lightcolor=p["border"],
            darkcolor=p["border"],
            relief="solid",
            borderwidth=1,
        )
        style.configure("Card.TLabel", background=p["surface"], foreground=p["text"])
        style.configure(
            "CardMuted.TLabel", background=p["surface"], foreground=p["muted"]
        )
        style.configure(
            "CardTitle.TLabel",
            background=p["surface"],
            foreground=p["text"],
            font=("Segoe UI", 20, "bold"),
        )
        style.configure(
            "HomeHeading.TLabel",
            background=p["bg"],
            foreground=p["text"],
            font=("Segoe UI", 20, "bold"),
        )
        style.configure(
            "PreviewFrame.TFrame",
            background=p["bg"],
            bordercolor=p["border"],
            lightcolor=p["border"],
            darkcolor=p["border"],
            relief="solid",
            borderwidth=1,
        )
        # Home-screen template card, and its "this one is active" state --
        # a thicker, primary-colored border so it's obvious at a glance
        # which template double-clicking any *other* card will switch away
        # from.
        style.configure(
            "HomeCard.TFrame",
            background=p["surface"],
            bordercolor=p["border"],
            lightcolor=p["border"],
            darkcolor=p["border"],
            relief="solid",
            borderwidth=1,
        )
        style.configure(
            "HomeCardSelected.TFrame",
            background=p["surface"],
            bordercolor=p["primary"],
            lightcolor=p["primary"],
            darkcolor=p["primary"],
            relief="solid",
            borderwidth=2,
        )

        # -- Buttons: base style + Primary (Add/Print) + Danger (Remove/Clear) --
        style.configure(
            "TButton",
            background=p["surface"],
            foreground=p["text"],
            bordercolor=p["border"],
            focusthickness=0,
            padding=(12, 6),
            font=FONT_BASE,
        )
        style.map(
            "TButton",
            background=[("active", p["row_alt"])],
        )

        style.configure(
            "Primary.TButton",
            background=p["primary"],
            foreground=p["accent_text"],
            bordercolor=p["primary"],
            padding=(14, 7),
            font=FONT_BOLD,
        )
        style.map(
            "Primary.TButton",
            background=[("pressed", p["primary_press"]), ("active", p["primary_hover"])],
            bordercolor=[("pressed", p["primary_press"]), ("active", p["primary_hover"])],
        )

        style.configure(
            "Danger.TButton",
            background=p["surface"],
            foreground=p["danger"],
            bordercolor=p["danger"],
            padding=(12, 6),
        )
        style.map(
            "Danger.TButton",
            background=[("pressed", p["danger"]), ("active", "#FEE2E2")],
            foreground=[("pressed", p["accent_text"])],
        )

        # -- Zebra-striped list rows (frame + label pair, referenced by index parity) --
        for name, bg in (("RowOdd", p["surface"]), ("RowEven", p["row_alt"])):
            style.configure(f"{name}.TFrame", background=bg)
            style.configure(f"{name}.TLabel", background=bg, foreground=p["text"])
            style.configure(f"{name}.TCheckbutton", background=bg)

    def _set_window_icon(self):
        if os.path.isfile(ICON_PATH):
            try:
                self.root.iconbitmap(ICON_PATH)
            except Exception:
                pass  # not on Windows, or Tk build without .ico support

    def _place_window(self, target_w, target_h, min_w, min_h):
        """Size + center the window against the *actual* screen this PC
        has, instead of trusting a hardcoded geometry string. A fixed
        "880x760" can end up partly or entirely off-screen on a smaller
        laptop display (Windows won't always pull an oversized window back
        into view), which looks exactly like the app failing to open --
        the process is alive, there's just nothing visible on screen.
        Reserves a margin for the taskbar + window title bar."""
        self.root.update_idletasks()
        screen_w = self.root.winfo_screenwidth()
        screen_h = self.root.winfo_screenheight()

        margin_w, margin_h = 40, 90  # taskbar + title bar + a little breathing room
        w = max(min_w, min(target_w, screen_w - margin_w))
        h = max(min_h, min(target_h, screen_h - margin_h))
        # If even the *minimum* size can't fit, still show something rather
        # than nothing -- shrink to fit the screen exactly.
        w = min(w, screen_w - 10)
        h = min(h, screen_h - 10)

        x = max(0, (screen_w - w) // 2)
        y = max(0, (screen_h - h) // 2 - 20)  # nudge up slightly, off the taskbar

        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self.root.minsize(min(min_w, w), min(min_h, h))

    # ---------------------------------------------------------- UI build --

    def _build_top_bar(self):
        bar = ttk.Frame(self.app_container, padding=10)
        bar.pack(fill="x")

        ttk.Label(bar, text="Scan / enter barcode:", style="Bold.TLabel").pack(side="left")
        self.barcode_entry = ttk.Entry(bar)
        self.barcode_entry.pack(side="left", fill="x", expand=True, padx=8, ipady=2)
        self.barcode_entry.bind("<Return>", self._on_add_barcode)
        self.barcode_entry.focus_set()

        ttk.Button(bar, text="Add", command=self._on_add_barcode, style="Primary.TButton").pack(
            side="left"
        )
        ttk.Button(
            bar, text="Load from file(s)…", command=self._on_load_from_files
        ).pack(side="left", padx=(6, 0))
        ttk.Button(
            bar, text="⚙ Settings", command=self._toggle_settings
        ).pack(side="right")
        ttk.Button(
            bar, text="Home", command=self._show_home
        ).pack(side="right", padx=(0, 6))

        self.flags_button = ttk.Button(
            bar, text="🚩 Price Flags", command=self._open_flags_window
        )
        self.flags_button.pack(side="right", padx=(0, 6))

        ttk.Button(
            bar, text="📱 Pair Phone", command=self._open_pair_window
        ).pack(side="right", padx=(0, 6))

    def _build_printer_bar(self):
        bar = ttk.Frame(self.app_container, padding=(10, 0, 10, 10))
        bar.pack(fill="x")

        ttk.Label(bar, text="Printer:").pack(side="left")
        self.printer_combo = ttk.Combobox(
            bar, textvariable=self.printer_var, state="readonly", width=40
        )
        self.printer_combo.pack(side="left", padx=8)

        ttk.Button(bar, text="Refresh", command=self._refresh_printers).pack(side="left")

        self._refresh_printers()

    def _refresh_printers(self):
        names, default = list_printers()
        self.printer_combo["values"] = names
        if names:
            current = self.printer_var.get()
            if current not in names:
                self.printer_var.set(default if default in names else names[0])
        else:
            self.printer_var.set("")
            self.printer_combo["values"] = ["(no printers found)"]

    def _build_main_area(self):
        """Holds the scrollable item list (left) and the collapsible
        Settings sidebar (right, hidden until the ⚙ button is clicked)."""
        self.main_area = ttk.Frame(self.app_container)
        self.main_area.pack(fill="both", expand=True)

        self._build_list_area(self.main_area)
        self._build_settings_sidebar(self.main_area)  # built but not packed yet

    def _build_list_area(self, parent):
        container = ttk.Frame(parent, padding=(10, 0, 10, 0))
        container.pack(side="left", fill="both", expand=True)

        header = ttk.Frame(container)
        header.pack(fill="x")
        self.select_all_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            header, variable=self.select_all_var, command=self._toggle_select_all
        ).pack(side="left")
        ttk.Label(header, text="Product", width=42, anchor="w", style="Bold.TLabel").pack(
            side="left", padx=(6, 0)
        )
        ttk.Label(header, text="Price", width=10, anchor="w", style="Bold.TLabel").pack(side="left")
        ttk.Label(header, text="Code", width=16, anchor="w", style="Bold.TLabel").pack(side="left")
        ttk.Separator(container).pack(fill="x", pady=4)

        canvas = tk.Canvas(container, highlightthickness=0, background=PALETTE["bg"])
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.list_frame = ttk.Frame(canvas)

        self.list_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=self.list_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    # -------------------------------------------------------- settings --

    def _build_settings_sidebar(self, parent):
        panel = ttk.Frame(parent, padding=12, width=240, relief="flat")
        panel.pack_propagate(False)
        self.settings_panel = panel  # not packed here -- _toggle_settings does that

        ttk.Label(panel, text="Settings", style="Header.TLabel").pack(anchor="w")
        ttk.Separator(panel).pack(fill="x", pady=(6, 10))

        ttk.Label(panel, text="Label Template", style="Bold.TLabel").pack(anchor="w")
        ttk.Label(
            panel,
            text="Pick which saved template new price tags\nare printed with.",
            style="Muted.TLabel",
            justify="left",
            wraplength=210,
        ).pack(anchor="w", pady=(2, 8))

        self.template_preview_label = ttk.Label(panel)
        self.template_preview_label.pack(pady=(0, 8))

        self.active_template_var = tk.StringVar(value=generate_label.get_active_template_name())
        self.template_combo = ttk.Combobox(
            panel, textvariable=self.active_template_var, state="readonly",
            values=generate_label.list_templates(),
        )
        self.template_combo.pack(fill="x")
        self.template_combo.bind("<<ComboboxSelected>>", self._on_template_selected)

        ttk.Button(
            panel, text="Edit / New Template…", command=self._on_open_template_editor
        ).pack(fill="x", pady=(8, 0))

        self._refresh_template_preview()

    def _on_open_template_editor(self):
        TemplateEditorWindow(
            self.root, start_name=self.active_template_var.get(),
            on_close=self._on_template_editor_closed,
        )

    def _on_template_editor_closed(self, active_name):
        """Called when the Template Editor window closes -- it may have
        renamed/deleted/added templates, and the user may have picked a
        different one to make active while in there."""
        names = generate_label.list_templates()
        self.template_combo.configure(values=names)
        if active_name and active_name in names:
            generate_label.set_active_template_name(active_name)
            self.active_template_var.set(active_name)
            self.settings["active_template"] = active_name
            save_settings(self.settings)
        self._refresh_template_preview()
        self._sync_template_controls()

    def _on_template_selected(self, event=None):
        name = self.active_template_var.get()
        generate_label.set_active_template_name(name)
        self.settings["active_template"] = name
        save_settings(self.settings)
        self._refresh_template_preview()
        self._sync_template_controls()

    def _toggle_settings(self):
        self.settings_visible = not self.settings_visible
        if self.settings_visible:
            self.settings_panel.pack(side="right", fill="y", padx=(8, 0))
        else:
            self.settings_panel.pack_forget()

    def _refresh_template_preview(self):
        try:
            sample = generate_label.get_sample_product(self.active_template_var.get())
            img = compose_label(sample)
            img.thumbnail((210, 150), Image.LANCZOS)
            self._template_thumb = ImageTk.PhotoImage(img)
            self.template_preview_label.configure(image=self._template_thumb)
        except Exception:
            self.template_preview_label.configure(image="")

    # ------------------------------------------------------- home screen --

    def _build_home_screen(self, parent):
        """Landing page shown when the app opens: every saved template
        shown side-by-side as its own card. Single-click a card to make it
        the active template; double-click to jump straight into the
        scan/print workflow with that template. A button below the cards
        starts a brand new template from scratch.

        Wrapped in a scrollable canvas (mouse wheel + a drag-able
        scrollbar) so that on a small screen -- where _place_window() may
        have had to shrink the window below this content's natural size --
        nothing is ever cut off; the user can just scroll down to see the
        rest instead of buttons vanishing off the bottom edge."""
        canvas = tk.Canvas(parent, highlightthickness=0, background=PALETTE["bg"])
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas, padding=(4, 4, 20, 4))

        inner.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        inner_window = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        # keep the inner frame exactly as wide as the canvas so text
        # wraplength / fill="x" widgets behave as the window is resized
        canvas.bind(
            "<Configure>", lambda e: canvas.itemconfigure(inner_window, width=e.width)
        )

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        def _bind_wheel(_event=None):
            canvas.bind_all("<MouseWheel>", _on_mousewheel)

        def _unbind_wheel(_event=None):
            canvas.unbind_all("<MouseWheel>")

        # Only steal the mouse wheel while it's actually over this screen --
        # bind_all is global, so it must be released again once the user
        # scrolls onto the app screen or this page is torn down.
        canvas.bind("<Enter>", _bind_wheel)
        canvas.bind("<Leave>", _unbind_wheel)

        ttk.Label(
            inner, text="Longwan Price Tag Printer", style="HomeHeading.TLabel"
        ).pack(anchor="w")
        ttk.Label(
            inner,
            text="Double-click a template below to start scanning and printing "
                 "with it. Single-click just switches which one is active. Use "
                 "Edit on a card to change its design, or design a brand new one.",
            style="Muted.TLabel",
            wraplength=680,
            justify="left",
        ).pack(anchor="w", pady=(4, 20))

        # Populated by _render_home_template_cards(): name -> card frame
        # (for highlighting the active one) and name -> PhotoImage (kept
        # alive so Tk doesn't garbage-collect the thumbnail out from under
        # the label showing it).
        self.home_cards = {}
        self._home_card_thumbs = {}

        self.home_cards_frame = ttk.Frame(inner)
        self.home_cards_frame.pack(fill="x")
        self._render_home_template_cards()

        btn_row = ttk.Frame(inner)
        btn_row.pack(fill="x", pady=(20, 0))
        ttk.Button(
            btn_row, text="Design New Template", style="Primary.TButton",
            command=self._on_design_new_template,
        ).pack(side="left")

    def _render_home_template_cards(self):
        """(Re)build the side-by-side row of template cards -- called on
        first load and whenever the set of saved templates changes (a
        template was added, renamed, or deleted in the Template Editor)."""
        for child in self.home_cards_frame.winfo_children():
            child.destroy()
        self.home_cards = {}

        names = generate_label.list_templates()
        columns = max(1, min(len(names), 3))
        for col in range(columns):
            self.home_cards_frame.columnconfigure(col, weight=1, uniform="home_card")

        for i, name in enumerate(names):
            card = self._build_home_template_card(self.home_cards_frame, name)
            row, col = divmod(i, columns)
            card.grid(
                row=row, column=col, sticky="nw",
                padx=(0 if col == 0 else 12, 0),
                pady=(0 if row == 0 else 12, 0),
            )
            self.home_cards[name] = card

    def _build_home_template_card(self, parent, name):
        is_active = name == generate_label.get_active_template_name()
        card = ttk.Frame(
            parent, padding=14,
            style="HomeCardSelected.TFrame" if is_active else "HomeCard.TFrame",
        )

        name_label = ttk.Label(card, text=name, style="CardTitle.TLabel")
        name_label.pack(anchor="w", pady=(0, 10))

        preview_wrap = ttk.Frame(card, style="PreviewFrame.TFrame")
        preview_wrap.pack(anchor="w")
        preview_label = ttk.Label(preview_wrap, style="Card.TLabel")
        preview_label.pack(padx=3, pady=3)
        try:
            tpl = generate_label.load_template(name)
            sample = generate_label.get_sample_product(name)
            img = compose_label(sample, template=tpl)
            img.thumbnail((260, 180), Image.LANCZOS)
            thumb = ImageTk.PhotoImage(img)
            self._home_card_thumbs[name] = thumb
            preview_label.configure(image=thumb)
        except Exception:
            preview_label.configure(text="(preview unavailable)", style="CardMuted.TLabel")

        hint = ttk.Label(
            card,
            text="Active -- double-click to open" if is_active else "Double-click to use",
            style="CardMuted.TLabel",
        )
        hint.pack(anchor="w", pady=(10, 0))

        ttk.Button(
            card, text="Edit", command=lambda n=name: self._on_edit_template_card(n)
        ).pack(anchor="e", pady=(8, 0))

        # ttk click events don't bubble from child to parent, so bind the
        # same handlers on the card and every clickable-looking child
        # (everything except the Edit button, which has its own command).
        for widget in (card, name_label, preview_wrap, preview_label, hint):
            widget.bind("<Button-1>", lambda e, n=name: self._on_home_card_click(n))
            widget.bind("<Double-Button-1>", lambda e, n=name: self._on_home_card_double_click(n))

        return card

    def _on_home_card_click(self, name):
        if name != generate_label.get_active_template_name():
            generate_label.set_active_template_name(name)
            self.settings["active_template"] = name
            save_settings(self.settings)
            self._sync_template_controls()

    def _on_home_card_double_click(self, name):
        self._on_home_card_click(name)
        self._show_app()

    def _highlight_home_cards(self):
        active = generate_label.get_active_template_name()
        for name, card in self.home_cards.items():
            card.configure(style="HomeCardSelected.TFrame" if name == active else "HomeCard.TFrame")
            for child in card.winfo_children():
                if isinstance(child, ttk.Label) and child.cget("style") == "CardMuted.TLabel" \
                        and "double-click" in child.cget("text").lower():
                    child.configure(
                        text="Active -- double-click to open" if name == active else "Double-click to use"
                    )

    def _on_edit_template_card(self, name):
        TemplateEditorWindow(
            self.root, start_name=name, on_close=self._on_home_template_editor_closed,
        )

    def _on_design_new_template(self):
        TemplateEditorWindow(
            self.root,
            start_name=generate_label.get_active_template_name(),
            start_new=True,
            on_close=self._on_home_template_editor_closed,
        )

    def _on_home_template_editor_closed(self, active_name):
        names = generate_label.list_templates()
        if active_name and active_name in names:
            generate_label.set_active_template_name(active_name)
            self.settings["active_template"] = active_name
            save_settings(self.settings)
        self._render_home_template_cards()
        self._sync_template_controls()

    def _sync_template_controls(self):
        """Keep the in-app Settings sidebar's template picker (built up
        front, alongside the home screen) in step with whatever was just
        changed from the home screen, and vice versa."""
        names = generate_label.list_templates()
        current = generate_label.get_active_template_name()
        if hasattr(self, "template_combo"):
            self.template_combo.configure(values=names)
            self.active_template_var.set(current)
            self._refresh_template_preview()
        if hasattr(self, "home_cards"):
            if set(self.home_cards.keys()) != set(names):
                self._render_home_template_cards()
            else:
                self._highlight_home_cards()

    def _show_home(self):
        self.app_container.pack_forget()
        self._sync_template_controls()
        self._place_window(*self.HOME_SIZE, *self.HOME_MINSIZE)
        self.home_frame.pack(fill="both", expand=True)

    def _show_app(self):
        self.home_frame.pack_forget()
        self._sync_template_controls()
        self._place_window(*self.APP_SIZE, *self.APP_MINSIZE)
        self.app_container.pack(fill="both", expand=True)
        self.barcode_entry.focus_set()

    def _build_bottom_bar(self):
        bar = ttk.Frame(self.app_container, padding=10)
        bar.pack(fill="x")

        self.status_var = tk.StringVar(value="0 items")
        ttk.Label(bar, textvariable=self.status_var, style="Muted.TLabel").pack(side="left")
        ttk.Button(bar, text="Export…", command=self._on_export).pack(side="left", padx=(12, 0))

        ttk.Button(bar, text="Print", command=self._on_print, style="Primary.TButton").pack(
            side="right", padx=(6, 0)
        )
        ttk.Button(bar, text="Clear", command=self._on_clear, style="Danger.TButton").pack(
            side="right", padx=(6, 0)
        )
        ttk.Button(bar, text="Remove", command=self._on_remove, style="Danger.TButton").pack(
            side="right", padx=(6, 0)
        )

    # ------------------------------------------------------------ actions --

    def _existing_codes(self):
        return {
            (it["product"].get("scan_code") or it["product"].get("barcode") or "")
            for it in self.items
        }

    def _claim_code(self, code):
        """True and reserves `code` if it's neither already a row in the
        list nor already mid-lookup from an earlier scan; False (does
        nothing) if a lookup for it is already in flight or it's already
        sitting in the list -- keeps a fast/duplicate scan from firing a
        second API call and adding a second row for the same product."""
        with self._pending_lock:
            if code in self._pending_codes or code in self._existing_codes():
                return False
            self._pending_codes.add(code)
            return True

    def _release_code(self, code):
        with self._pending_lock:
            self._pending_codes.discard(code)

    def _on_add_barcode(self, event=None):
        code = self.barcode_entry.get().strip()
        if not code:
            return
        self.barcode_entry.delete(0, "end")
        if not self._claim_code(code):
            return  # already in the list, or already being looked up
        # Submitted to the shared bounded pool rather than spawned as its
        # own raw thread -- a gondola scanner rattling off several codes a
        # second just queues past MAX_FETCH_WORKERS in flight, instead of
        # opening a new API connection per scan.
        self._fetch_executor.submit(self._fetch_and_add, code)

    def _fetch_and_add(self, code):
        try:
            doc = fetch_product_by_barcode(code)
            items = doc.get("items", []) if isinstance(doc, dict) else []
            if not items:
                self.root.after(
                    0, lambda: messagebox.showwarning("Not found", f"No product found for {code}")
                )
                return
            for product in items:
                self.root.after(0, lambda p=product: self._add_row(p))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Lookup failed", str(e)))
        finally:
            self._release_code(code)

    def _on_app_close(self):
        # cancel_futures drops anything still queued (a burst that outran
        # the pool right as the window closed) instead of blocking exit on
        # requests nobody's waiting to see the result of; each individual
        # lookup is still capped at 5s (see fetch_product_by_barcode) so
        # even an in-flight one can't hang the close for long.
        self._fetch_executor.shutdown(wait=False, cancel_futures=True)
        self.root.destroy()
        # concurrent.futures.ThreadPoolExecutor registers a global atexit
        # hook that blocks interpreter shutdown until every worker thread
        # it ever spawned finishes -- including the (untimed) A4 render
        # pool and any other in-flight executor elsewhere in the app. That
        # makes pythonw.exe -- and therefore the console window hosting it
        # in Start Price Tag Tool.bat -- sit around for seconds after the
        # window has already visually closed. By this point any file
        # writes (CSV/PDF export) are already done and nothing left
        # in-flight is something the user is still waiting to see, so a
        # hard exit is safe and gives an instant, reliable close every
        # time instead of an unpredictable hang.
        os._exit(0)

    # --- Price Checker PWA intake ------------------------------------------
    def _poll_flags(self):
        """Every few seconds, refresh the badge count on the Price Flags
        button so staff notice new phone-flagged mismatches without having
        to keep the flags window open."""
        n = self.flag_queue.count()
        label = f"🚩 Price Flags ({n})" if n else "🚩 Price Flags"
        self.flags_button.configure(text=label)
        if self._flags_window is not None and self._flags_window.winfo_exists():
            self._flags_window.refresh()
        self.root.after(3000, self._poll_flags)

    def _open_flags_window(self):
        if self._flags_window is not None and self._flags_window.winfo_exists():
            self._flags_window.lift()
            self._flags_window.focus_set()
            return
        self._flags_window = FlagsWindow(self.root, self.flag_queue, self._add_row)

    def _open_pair_window(self):
        if self.flag_server_port is None:
            messagebox.showerror(
                "Price Flag server not running",
                "The local server didn't start this session (see the console for why),"
                " so there's nothing for a phone to pair with right now.",
            )
            return
        PairWindow(self.root, self.flag_server_port, generate_label.BRANCH_ID)

    def _on_load_from_files(self):
        """
        Batch-import: pick one or more scanned-code text files (the OTG
        scanner -> phone notes app -> gondola1.txt / gondola2.txt workflow
        from the CLI's --barcode-list, now available from the GUI too).
        """
        paths = filedialog.askopenfilenames(
            title="Choose scanned barcode file(s)",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if not paths:
            return
        threading.Thread(
            target=self._load_codes_from_files, args=(paths,), daemon=True
        ).start()

    def _load_codes_from_files(self, paths):
        try:
            codes = load_codes_from_list_files(paths)
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Load failed", str(e)))
            return

        # Skip codes already sitting in the list so re-loading a file (or an
        # overlapping gondola file) doesn't duplicate rows.
        existing_codes = self._existing_codes()
        to_fetch = [c for c in codes if c not in existing_codes]
        skipped_existing = len(codes) - len(to_fetch)

        added = 0
        failed = []

        def _fetch(code):
            try:
                doc = fetch_product_by_barcode(code)
                items = doc.get("items", []) if isinstance(doc, dict) else []
                if not items:
                    return code, None, "no product found"
                return code, items, None
            except Exception as e:
                return code, None, str(e)

        # These are network lookups (I/O-bound, dominated by round-trip
        # latency to the store API), so running several concurrently on a
        # small thread pool cuts a large batch's wait time roughly by the
        # worker count instead of paying every request's latency back to
        # back -- the GIL isn't a bottleneck here since each thread spends
        # almost all its time blocked on the network, not on Python code.
        # pool.map still yields results in the original `to_fetch` order
        # even though the requests themselves race ahead concurrently, so
        # rows appear in the same order they would have sequentially.
        if to_fetch:
            with ThreadPoolExecutor(max_workers=min(MAX_FETCH_WORKERS, len(to_fetch))) as pool:
                for code, items, err in pool.map(_fetch, to_fetch):
                    if err:
                        failed.append((code, err))
                        continue
                    for product in items:
                        self.root.after(0, lambda p=product: self._add_row(p))
                        added += 1

        def _report():
            msg = f"Loaded {added} item(s) from {len(paths)} file(s)."
            if skipped_existing:
                msg += f"\n{skipped_existing} code(s) skipped (already in list)."
            if failed:
                shown = failed[:20]
                msg += "\n\nFailed:\n" + "\n".join(f"- {c}: {err}" for c, err in shown)
                if len(failed) > 20:
                    msg += f"\n...and {len(failed) - 20} more."
            messagebox.showinfo("Load from file(s)", msg)

        self.root.after(0, _report)

    def _add_row(self, product):
        # Zebra stripe: alternate style based on position in the list.
        row_style = "RowEven" if len(self.items) % 2 else "RowOdd"

        row = ttk.Frame(self.list_frame, style=f"{row_style}.TFrame")
        row.pack(fill="x")

        var = tk.BooleanVar(value=True)
        ttk.Checkbutton(row, variable=var, style=f"{row_style}.TCheckbutton").pack(
            side="left", padx=(4, 0), pady=4
        )

        name = product.get("description", "").strip()
        try:
            price_display = f"RM {float(product.get('price', 0)):.2f}"
        except (TypeError, ValueError):
            price_display = str(product.get("price", ""))
        code = product.get("scan_code") or product.get("barcode") or ""

        ttk.Label(
            row, text=name, width=42, anchor="w", style=f"{row_style}.TLabel"
        ).pack(side="left", padx=(6, 0), pady=4)
        ttk.Label(
            row, text=price_display, width=10, anchor="w", style=f"{row_style}.TLabel"
        ).pack(side="left", pady=4)
        ttk.Label(
            row, text=code, width=16, anchor="w", style=f"{row_style}.TLabel"
        ).pack(side="left", pady=4)

        self.items.append({"product": product, "var": var, "frame": row})
        self._update_status()

    def _toggle_select_all(self):
        val = self.select_all_var.get()
        for it in self.items:
            it["var"].set(val)

    def _on_remove(self):
        keep = []
        for it in self.items:
            if it["var"].get():
                it["frame"].destroy()
            else:
                keep.append(it)
        self.items = keep
        self._restripe_rows()
        self._update_status()

    def _restripe_rows(self):
        """Re-apply the zebra stripe styles after rows are removed, so the
        alternating pattern stays continuous instead of freezing in place."""
        for i, it in enumerate(self.items):
            row_style = "RowEven" if i % 2 else "RowOdd"
            it["frame"].configure(style=f"{row_style}.TFrame")
            for child in it["frame"].winfo_children():
                cls = child.winfo_class()
                suffix = "TCheckbutton" if cls == "TCheckbutton" else "TLabel"
                child.configure(style=f"{row_style}.{suffix}")

    def _on_clear(self):
        if not self.items:
            return
        if not messagebox.askyesno("Clear list", "Remove all items from the list?"):
            return
        for it in self.items:
            it["frame"].destroy()
        self.items = []
        self._update_status()

    def _on_export(self):
        """Export the current list (all rows, ticked or not) to a CSV file."""
        if not self.items:
            messagebox.showinfo("Export", "No items to export.")
            return
        path = filedialog.asksaveasfilename(
            title="Export list",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile="price_tag_list.csv",
        )
        if not path:
            return
        try:
            # utf-8-sig so Excel (common in MY offices) opens it without
            # mangling non-ASCII product names.
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(["code", "description", "price", "uom"])
                for it in self.items:
                    p = it["product"]
                    code = p.get("scan_code") or p.get("barcode") or ""
                    writer.writerow(
                        [code, p.get("description", ""), p.get("price", ""), p.get("uom", "")]
                    )
            messagebox.showinfo("Export", f"Exported {len(self.items)} item(s) to {path}")
        except Exception as e:
            messagebox.showerror("Export failed", str(e))

    # ---- Print: render -> build A4 pages -> preview -> (confirm) -> send --

    def _on_print(self):
        checked = [it["product"] for it in self.items if it["var"].get()]
        if not checked:
            messagebox.showinfo("Print", "No items ticked.")
            return
        active_tpl = generate_label.get_active_template()
        if generate_label.template_uses_field(active_tpl, "promo_price"):
            # This template has a promo-price box -- it can't come from the
            # API, so collect one per product (and block on any left blank)
            # before rendering anything.
            PromoPriceWindow(
                self.root, checked, self.promo_price_cache,
                on_save_cache=self._save_promo_cache,
                on_confirmed=lambda: self._start_render(checked),
            )
            return
        self._start_render(checked)

    def _start_render(self, checked):
        threading.Thread(target=self._render_a4_pages, args=(checked,), daemon=True).start()

    def _save_promo_cache(self):
        self.settings["promo_price_cache"] = self.promo_price_cache
        save_settings(self.settings)

    def _label_cache_key(self, product, template):
        """Hash identifying 'this exact label design' -- everything that
        actually affects compose_label()'s pixel output: the full active
        template (so any edit in the Template Editor invalidates every
        cached label automatically) plus the product fields that get drawn
        (barcode/description/price/uom/promo price). Two calls with the
        same key are guaranteed to render identically, so the second one
        can just reuse the first's PNG instead of recomposing it."""
        payload = {
            "template": template,
            "barcode": product.get("scan_code") or product.get("barcode"),
            "description": product.get("description"),
            "price": product.get("price"),
            "uom": product.get("uom"),
            "promo_price": product.get("_promo_price"),
        }
        blob = json.dumps(payload, sort_keys=True, default=str)
        return hashlib.md5(blob.encode("utf-8")).hexdigest()

    def _render_a4_pages(self, products):
        """Runs off the UI thread: composes labels + tiles them onto A4 pages."""
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        active_tpl = generate_label.get_active_template()

        def _render_one(p):
            try:
                key = self._label_cache_key(p, active_tpl)
                cached_path = self._label_render_cache.get(key)
                if cached_path and os.path.exists(cached_path):
                    # Same template + same product/price/promo as a previous
                    # render (e.g. Cancel out of Preview and hit Print again
                    # with nothing changed) -- skip composing this one again.
                    return p, cached_path, None
                img = compose_label(p, template=active_tpl)
                safe_code = (p.get("scan_code") or p.get("barcode") or "label").replace("/", "_")
                out_path = os.path.join(OUTPUT_DIR, f"{safe_code}.png")
                img.save(out_path)
                self._label_render_cache[key] = out_path
                return p, out_path, None
            except Exception as e:
                return p, None, str(e)

        # Composing each label (font/text layout + barcode generation) and
        # saving its PNG are independent per product, so spreading them
        # across a small thread pool overlaps the disk-I/O portions and
        # keeps a big batch from waiting on one label at a time. Results
        # are collected via map() so label_paths still comes out in the
        # same order the products were ticked in.
        with ThreadPoolExecutor(max_workers=min(MAX_RENDER_WORKERS, len(products) or 1)) as pool:
            results = list(pool.map(_render_one, products))

        label_paths = []
        failed = []
        for p, path, err in results:
            if err:
                failed.append((p.get("description", "?"), err))
            else:
                label_paths.append(path)

        if not label_paths:
            detail = "\n".join(f"- {n}: {err}" for n, err in failed[:10])
            if len(failed) > 10:
                detail += f"\n...and {len(failed) - 10} more."
            self.root.after(
                0,
                lambda: messagebox.showerror(
                    "Print", f"No labels could be rendered.\n\n{detail}"
                ),
            )
            return

        self.root.after(0, lambda: self._show_preview(label_paths, failed, products))

    def _write_print_report(self, products, failed, pages, cols, pdf_path):
        """Writes a per-job CSV report (what was printed, layout used, any
        failures) to output/reports/, timestamped so past runs aren't
        overwritten. This is separate from the manual 'Export' button --
        that exports the on-screen list on demand; this is an automatic
        record of what actually got rendered for this specific print job."""
        import datetime

        reports_dir = os.path.join(OUTPUT_DIR, "reports")
        os.makedirs(reports_dir, exist_ok=True)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = os.path.join(reports_dir, f"print_report_{timestamp}.csv")

        try:
            with open(report_path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(["Print job report", timestamp])
                writer.writerow(["Template", generate_label.get_active_template()])
                writer.writerow(["Layout", f"{cols} per row x {A4_ROWS} rows ({cols * A4_ROWS} per page)"])
                writer.writerow(["Pages", len(pages)])
                writer.writerow(["Tags printed", len(products) - len(failed)])
                writer.writerow(["Tags failed", len(failed)])
                writer.writerow(["PDF", pdf_path])
                writer.writerow([])
                writer.writerow(["status", "barcode", "description", "price", "promo_price", "uom"])
                failed_names = {name for name, _err in failed}
                for p in products:
                    code = p.get("scan_code") or p.get("barcode") or ""
                    name = p.get("description", "")
                    status = "FAILED" if name in failed_names else "printed"
                    writer.writerow(
                        [status, code, name, p.get("price", ""), p.get("_promo_price", ""), p.get("uom", "")]
                    )
                if failed:
                    writer.writerow([])
                    writer.writerow(["Failure details"])
                    for name, err in failed:
                        writer.writerow(["", "", name, err])
            return report_path
        except Exception:
            return None  # non-fatal -- the print job itself already succeeded

    def _show_preview(self, label_paths, failed, products):
        if failed:
            messagebox.showwarning(
                "Some labels failed",
                "\n".join(f"- {n}: {err}" for n, err in failed),
            )
        # Layout (tags per row) is chosen live inside the preview dialog --
        # like a normal print dialog's layout setting -- not decided up
        # front, so the A4 page tiling/PDF/report only happen once the user
        # confirms, using whatever column count they landed on.
        PreviewWindow(
            self.root, label_paths, initial_cols=self.cols_var.get(),
            on_confirm=lambda pages, cols: self._confirm_and_print(
                pages, cols, label_paths, failed, products
            ),
            on_export=lambda pages, cols, close_preview: self._export_pages(
                pages, cols, failed, products, close_preview
            ),
        )

    def _export_pages(self, pages, cols, failed, products, close_preview):
        """Saves the current preview layout straight to a PDF the user
        picks (plus its matching job report) without sending anything to
        a printer. Cancelling the save dialog leaves the preview open with
        no side effects, same as Cancel does."""
        path = filedialog.asksaveasfilename(
            title="Export A4 sheet as PDF",
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
            initialfile="a4_sheets.pdf",
        )
        if not path:
            return  # user cancelled -- preview stays open, nothing written

        first, rest = pages[0], pages[1:]
        first.save(path, "PDF", resolution=300, save_all=True, append_images=rest)
        report_path = self._write_print_report(products, failed, pages, cols, path)

        # Remember the layout choice for next time, same as a real print does.
        self.cols_var.set(cols)
        self.settings["tags_per_row"] = cols
        save_settings(self.settings)

        close_preview()

        msg = f"Exported {len(pages)} A4 page(s) to:\n{path}"
        if report_path:
            msg += f"\n\nJob report saved to:\n{report_path}"
        messagebox.showinfo("Export", msg)

    def _confirm_and_print(self, pages, cols, label_paths, failed, products):
        n_tags = len(label_paths)
        if n_tags < MIN_TAGS_NO_CONFIRM:
            proceed = messagebox.askyesno(
                "Confirm print",
                f"This job is only {n_tags} price tag{'s' if n_tags != 1 else ''} — "
                f"less than a full run of {MIN_TAGS_NO_CONFIRM}. Print anyway?",
            )
            if not proceed:
                return

        # Remember the layout choice for next time.
        self.cols_var.set(cols)
        self.settings["tags_per_row"] = cols
        save_settings(self.settings)

        pdf_path = os.path.join(OUTPUT_DIR, "a4_sheets.pdf")
        first, rest = pages[0], pages[1:]
        first.save(pdf_path, "PDF", resolution=300, save_all=True, append_images=rest)
        report_path = self._write_print_report(products, failed, pages, cols, pdf_path)

        printer_name = self.printer_var.get()
        if not printer_name or printer_name == "(no printers found)":
            printer_name = None  # falls back to the system default
        threading.Thread(
            target=self._send_to_printer, args=(pages, pdf_path, printer_name, report_path), daemon=True
        ).start()

    def _send_to_printer(self, pages, pdf_path, printer_name, report_path=None):
        try:
            print_pages_gdi(pages, printer_name)
            msg = f"Sent {len(pages)} A4 page(s) to the printer."
            if report_path:
                msg += f"\n\nJob report saved to:\n{report_path}"
            self.root.after(0, lambda: messagebox.showinfo("Print", msg))
            return
        except Exception as gdi_err:
            # GDI path failed -- fall back to the old ShellExecute-on-PDF
            # approach in case this machine's printer driver has trouble
            # with direct GDI printing but still handles PDFs fine via
            # whatever's registered for .pdf.
            try:
                print_pages(pages, pdf_path, printer_name)
                msg = f"Sent {len(pages)} A4 page(s) to the printer."
                if report_path:
                    msg += f"\n\nJob report saved to:\n{report_path}"
                self.root.after(0, lambda: messagebox.showinfo("Print", msg))
                return
            except Exception as shell_err:
                msg = (
                    f"Saved to {pdf_path}, but sending to the printer failed.\n\n"
                    f"Direct printing: {gdi_err}\n\nPDF printing: {shell_err}"
                )
                if report_path:
                    msg += f"\n\nJob report saved to:\n{report_path}"
                msg += "\n\nOpen the PDF now so you can print it manually instead?"
        self.root.after(0, lambda: self._offer_manual_print(pdf_path, msg))

    def _offer_manual_print(self, pdf_path, msg):
        if messagebox.askyesno("Print failed", msg):
            try:
                os.startfile(pdf_path)  # "open" verb -- just opens the PDF in
                                         # whatever viewer is registered, no
                                         # print verb needed, so this works
                                         # even when print_pages() couldn't
            except Exception as e:
                messagebox.showerror("Couldn't open PDF", str(e))

    def _update_status(self):
        n = len(self.items)
        self.status_var.set(f"{n} item{'s' if n != 1 else ''}")


class PairWindow(tk.Toplevel):
    """
    Shows this machine's LAN address (as text, plus a QR code for anyone
    who wants to scan it with a separate camera/QR app) so a staff phone
    can be pointed at it without typing an IP by hand. The Price Checker
    app itself no longer scans QR codes -- staff type the address shown
    here into Settings once. Also useful to re-pair if the machine's IP
    changes (DHCP) -- just reopen this and read the new address off.
    """

    def __init__(self, parent, port, branch_id):
        super().__init__(parent)
        self.title("Pair Phone — Price Checker")
        self.resizable(False, False)
        self.transient(parent)

        lan_ips = list_lan_ips()
        ip = lan_ips[0]
        scheme = "https" if is_https_enabled() else "http"
        url = f"{scheme}://{ip}:{port}"
        payload = json.dumps({"url": url, "branch_id": branch_id})

        ttk.Label(self, text="Pair a Phone", style="Header.TLabel").pack(
            anchor="w", padx=16, pady=(16, 4)
        )
        ttk.Label(
            self,
            text="In the Price Checker app: Settings → type the address\n"
                 "below into \"Price Tag Tool address\", then Save.\n"
                 "Phone must be on the same Wi-Fi as this computer.",
            style="Muted.TLabel", justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 12))

        if qrcode is None:
            ttk.Label(
                self,
                text="qrcode package not installed — run:\n"
                     "  pip install qrcode\n\nType this address manually instead:",
                style="Muted.TLabel", justify="left",
            ).pack(anchor="w", padx=16, pady=8)
        else:
            qr = qrcode.QRCode(border=2, box_size=8)
            qr.add_data(payload)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
            self._qr_photo = ImageTk.PhotoImage(img)  # keep a reference
            ttk.Label(self, image=self._qr_photo).pack(padx=16, pady=(0, 12))

        addr_frame = ttk.Frame(self, padding=(16, 0, 16, 16))
        addr_frame.pack(fill="x")
        ttk.Label(addr_frame, text=url, style="Bold.TLabel").pack(anchor="w")
        ttk.Label(addr_frame, text=f"Branch {branch_id}", style="Muted.TLabel").pack(anchor="w")

        if len(lan_ips) > 1:
            others = ", ".join(f"{scheme}://{other}:{port}" for other in lan_ips[1:])
            ttk.Label(
                self,
                text=f"This computer has more than one network address.\n"
                     f"If the phone can't connect with the one above, try:\n{others}",
                style="Muted.TLabel", justify="left", wraplength=360,
            ).pack(anchor="w", padx=16, pady=(0, 10))

        btn_row = ttk.Frame(self, padding=(16, 0, 16, 16))
        btn_row.pack(fill="x")
        ttk.Button(
            btn_row, text="Refresh (IP changed?)",
            command=lambda: self._refresh(port, branch_id),
        ).pack(side="left")
        ttk.Button(
            btn_row, text="Phone can't connect?",
            command=self._run_diagnostics,
        ).pack(side="left", padx=(8, 0))

    def _run_diagnostics(self):
        import subprocess
        import sys as _sys
        here = os.path.dirname(os.path.abspath(__file__))
        script = os.path.join(here, "diagnose_network.py")
        try:
            if os.name == "nt":
                subprocess.Popen(
                    f'start "Price Tag Tool -- Network Diagnostics" cmd /k "{_sys.executable}" "{script}"',
                    shell=True,
                )
            else:
                subprocess.Popen([_sys.executable, script])
        except Exception as e:
            messagebox.showerror(
                "Couldn't launch diagnostics",
                f"Run this manually from a terminal in the pricetag_tool folder:\n\n"
                f"python diagnose_network.py\n\n({e})",
            )

    def _refresh(self, port, branch_id):
        self.destroy()
        PairWindow(self.master, port, branch_id)


class FlagsWindow(tk.Toplevel):
    """
    Lists price mismatches phoned in by the Price Checker PWA: staff scanned
    a barcode on the floor, the phone looked it up via the same api.php this
    tool uses, and the price on the printed shelf tag didn't match. Each row
    shows both prices side by side so it's obvious at a glance which need a
    reprint.

    "Add to batch" ticks the item into the normal print list via the exact
    same _add_row() path as scanning a barcode here directly -- so it flows
    through the existing template/print pipeline unchanged. "Dismiss"
    removes a flag without printing (e.g. a staff typo on the shelf-price
    entry). Nothing here talks to the internet; flags only ever arrive over
    the LAN from phones on the same network.
    """

    def __init__(self, parent, flag_queue, add_row_callback):
        super().__init__(parent)
        self.title("Price Flags from Price Checker")
        self.geometry("640x420")
        self.minsize(560, 320)
        self.transient(parent)

        self.flag_queue = flag_queue
        self.add_row_callback = add_row_callback
        self.row_vars = []  # list of (flag_dict, tk.BooleanVar)

        ttk.Label(self, text="Price Flags", style="Header.TLabel").pack(
            anchor="w", padx=14, pady=(14, 0)
        )
        ttk.Label(
            self,
            text="Reported by staff via the Price Checker phone app when a shelf\n"
                 "tag's price didn't match the system. Review, then add the ones\n"
                 "that need a reprint to the batch below.",
            style="Muted.TLabel", justify="left",
        ).pack(anchor="w", padx=14, pady=(2, 10))

        header = ttk.Frame(self, padding=(14, 0))
        header.pack(fill="x")
        for text, w in [("", 3), ("Product", 26), ("System RM", 10), ("Shelf RM", 10), ("Reported", 14)]:
            ttk.Label(header, text=text, width=w, anchor="w", style="Bold.TLabel").pack(side="left")

        # IMPORTANT: pack this bottom bar (fixed height, side="bottom") BEFORE
        # the expanding list_container below. Tk's pack() geometry manager
        # hands an expand=True widget the *entire* remaining cavity at the
        # moment it's processed -- it doesn't reserve space in advance for
        # siblings added later. Packing list_container first (as this used
        # to) left nothing for these buttons, squeezing them down to a
        # sliver where only the border color was visible and the label text
        # had no room to draw. side="bottom" + packing first guarantees this
        # bar gets its natural size carved out from the bottom edge first.
        bottom = ttk.Frame(self, padding=14)
        bottom.pack(side="bottom", fill="x")
        ttk.Button(
            bottom, text="✓ Add ticked to batch", command=self._on_add_ticked,
            style="Primary.TButton", width=20,
        ).pack(side="left")
        ttk.Button(
            bottom, text="✕ Dismiss ticked", command=self._on_dismiss_ticked,
            style="Danger.TButton", width=16,
        ).pack(side="left", padx=(6, 0))
        ttk.Button(bottom, text="Close", command=self.destroy, width=10).pack(side="right")

        list_container = ttk.Frame(self, padding=(14, 0))
        list_container.pack(fill="both", expand=True)
        canvas = tk.Canvas(list_container, highlightthickness=0, background=PALETTE["bg"])
        vscroll = ttk.Scrollbar(list_container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vscroll.set)
        self.rows_frame = ttk.Frame(canvas)
        self.rows_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=self.rows_frame, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(canvas_window, width=e.width))
        canvas.pack(side="left", fill="both", expand=True)
        vscroll.pack(side="right", fill="y")

        self.empty_label = ttk.Label(
            self.rows_frame, text="No pending flags.", style="Muted.TLabel"
        )

        self.refresh()

    def refresh(self):
        for child in self.rows_frame.winfo_children():
            child.destroy()
        self.row_vars = []

        flags = self.flag_queue.list_pending()
        if not flags:
            self.empty_label = ttk.Label(
                self.rows_frame, text="No pending flags.", style="Muted.TLabel"
            )
            self.empty_label.pack(anchor="w", pady=10)
            return

        for i, flag in enumerate(flags):
            row_style = "RowEven" if i % 2 else "RowOdd"
            row = ttk.Frame(self.rows_frame, style=f"{row_style}.TFrame")
            row.pack(fill="x")

            var = tk.BooleanVar(value=True)
            ttk.Checkbutton(row, variable=var, style=f"{row_style}.TCheckbutton").pack(
                side="left", padx=(4, 0), pady=4
            )
            name = (flag.get("description") or "").strip() or flag.get("barcode", "")
            ttk.Label(row, text=name, width=26, anchor="w", style=f"{row_style}.TLabel").pack(
                side="left", pady=4
            )
            ttk.Label(
                row, text=_fmt_rm(flag.get("system_price")), width=10, anchor="w",
                style=f"{row_style}.TLabel",
            ).pack(side="left", pady=4)
            ttk.Label(
                row, text=_fmt_rm(flag.get("shelf_price")), width=10, anchor="w",
                style="Bold.TLabel",
            ).pack(side="left", pady=4)
            reported = flag.get("received_at", "")[:16].replace("T", " ")
            ttk.Label(row, text=reported, width=14, anchor="w", style=f"{row_style}.TLabel").pack(
                side="left", pady=4
            )
            self.row_vars.append((flag, var))

    def _ticked_flags(self):
        return [flag for flag, var in self.row_vars if var.get()]

    def _on_add_ticked(self):
        ticked = self._ticked_flags()
        if not ticked:
            return
        for flag in ticked:
            product = {
                "description": flag.get("description", ""),
                "price": flag.get("system_price", "0.00"),
                "uom": flag.get("uom", ""),
                "barcode": flag.get("barcode", ""),
                "scan_code": flag.get("scan_code") or flag.get("barcode", ""),
            }
            self.add_row_callback(product)
        self.flag_queue.remove([f["id"] for f in ticked])
        self.refresh()

    def _on_dismiss_ticked(self):
        ticked = self._ticked_flags()
        if not ticked:
            return
        if not messagebox.askyesno(
            "Dismiss flags", f"Dismiss {len(ticked)} flag(s) without adding them to the batch?"
        ):
            return
        self.flag_queue.remove([f["id"] for f in ticked])
        self.refresh()


def _fmt_rm(value):
    try:
        return f"{float(value):.2f}"
    except (TypeError, ValueError):
        return str(value or "")



class PromoPriceWindow(tk.Toplevel):
    """
    Shown before printing whenever the active template has a box bound to
    the "promo_price" field -- e.g. a HARGA KEAHLIAN / membership-promo
    layout where the discounted price can't come from the product API and
    has to be typed in by hand for this print run.

    One row per product: its barcode (read-only but selectable, so it can
    be copy-pasted elsewhere to cross-check against a promo list), its
    description, its normal price (read-only, straight from the API -- for
    comparing against while typing the promo price), and an editable promo
    price entry, pre-filled from whatever was entered for that barcode last
    time (promos don't change often).
    "Continue" is blocked -- with the first offending row's entry
    highlighted red and focused -- until every row has a non-blank price;
    there's no way to send a promo tag to print with the price left blank.
    Cancel is a true no-op: nothing is written, no print job starts.
    """

    ROW_HEIGHT = 34
    MAX_VISIBLE_ROWS = 8

    def __init__(self, parent, products, cache, on_save_cache, on_confirmed):
        super().__init__(parent)
        self.title("Promotion price")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.cache = cache
        self.on_save_cache = on_save_cache
        self.on_confirmed = on_confirmed
        self.rows = []  # (product, barcode, tk.StringVar, ttk.Entry)

        ttk.Label(self, text="Promotion price", style="Header.TLabel").pack(
            anchor="w", padx=14, pady=(14, 0)
        )
        ttk.Label(
            self,
            text="This template needs a promotion price for each item below --\n"
                 "it can't be pulled from the system automatically. Check the\n"
                 "barcode against your promo list before entering it.",
            style="Muted.TLabel", justify="left",
        ).pack(anchor="w", padx=14, pady=(2, 10))

        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True, padx=14)

        header = ttk.Frame(outer)
        header.pack(fill="x")
        ttk.Label(header, text="Barcode", width=16, style="Bold.TLabel").pack(side="left")
        ttk.Label(header, text="Product", width=26, style="Bold.TLabel").pack(side="left")
        ttk.Label(header, text="Normal price", width=12, style="Bold.TLabel").pack(side="left")
        ttk.Label(header, text="Promo price (RM)", style="Bold.TLabel").pack(side="left")

        visible_rows = min(len(products), self.MAX_VISIBLE_ROWS)
        canvas_h = visible_rows * self.ROW_HEIGHT
        canvas = tk.Canvas(
            outer, width=620, height=canvas_h,
            highlightthickness=0, background=PALETTE["bg"],
        )
        rows_frame = ttk.Frame(canvas)
        rows_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=rows_frame, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(canvas_window, width=e.width))

        if len(products) > self.MAX_VISIBLE_ROWS:
            vscroll = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
            canvas.configure(yscrollcommand=vscroll.set)
            vscroll.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        for product in products:
            code = product.get("scan_code") or product.get("barcode") or ""
            name = (product.get("description") or "").strip()
            try:
                normal_price = f"RM {float(product.get('price', 0)):.2f}"
            except (TypeError, ValueError):
                normal_price = str(product.get("price", ""))

            row = ttk.Frame(rows_frame)
            row.pack(fill="x", pady=2)

            code_entry = ttk.Entry(row, width=16)
            code_entry.insert(0, code)
            code_entry.configure(state="readonly")  # visible + selectable, not editable
            code_entry.pack(side="left")

            ttk.Label(row, text=name[:26], width=26, anchor="w").pack(side="left")

            price_entry = ttk.Entry(row, width=12)
            price_entry.insert(0, normal_price)
            price_entry.configure(state="readonly")  # from the API, not editable here
            price_entry.pack(side="left")

            var = tk.StringVar(value=self.cache.get(code, ""))
            entry = ttk.Entry(row, textvariable=var, width=14)
            entry.pack(side="left")

            self.rows.append((product, code, var, entry))

        bottom = ttk.Frame(self, padding=14)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(
            bottom, text="Continue to preview", command=self._on_continue, style="Primary.TButton"
        ).pack(side="right", padx=(0, 6))

    def _on_continue(self):
        first_bad = None
        bad_reason = None  # "blank" or "invalid" -- for the first offending row
        parsed = {}  # code -> float, only for rows that pass

        for product, code, var, entry in self.rows:
            text = var.get().strip()
            if not text:
                entry.configure(style="Invalid.TEntry")
                if first_bad is None:
                    first_bad, bad_reason = entry, "blank"
                continue
            try:
                value = float(text)
            except ValueError:
                entry.configure(style="Invalid.TEntry")
                if first_bad is None:
                    first_bad, bad_reason = entry, "invalid"
                continue
            if value < 0:
                entry.configure(style="Invalid.TEntry")
                if first_bad is None:
                    first_bad, bad_reason = entry, "negative"
                continue
            entry.configure(style="TEntry")
            parsed[code] = value

        if first_bad is not None:
            first_bad.focus_set()
            messages = {
                "blank": "Every item needs a promotion price before printing -- "
                          "fill in the highlighted row(s) (blank isn't allowed).",
                "invalid": "The highlighted promo price isn't a valid number -- "
                            "use digits only (e.g. 65.75, not 'RM65.75' or '65,75').",
                "negative": "The highlighted promo price can't be negative.",
            }
            messagebox.showwarning(
                "Promotion price required", messages[bad_reason], parent=self,
            )
            return

        # All rows validated as floats -- standardize storage/display to a
        # fixed 2-decimal string (e.g. "65.7" -> "65.70") so promo prices
        # match the "RM {:.2f}" formatting used everywhere else on the tag,
        # instead of preserving whatever raw text the user happened to type.
        for product, code, var, entry in self.rows:
            standardized = f"{parsed[code]:.2f}"
            product["_promo_price"] = standardized
            self.cache[code] = standardized
        self.on_save_cache()

        self.destroy()
        self.on_confirmed()


class PreviewWindow(tk.Toplevel):
    """
    Shows the A4 page(s) about to be printed, one at a time, before anything
    is sent to the printer. A "Tags per row" control here lets the user
    change the layout live -- like a normal print dialog's layout setting --
    rebuilding the page preview on the fly. Nothing is tiled onto a final
    PDF/report until Print is actually clicked, so switching layouts back
    and forth here has no side effects. Cancel closes with no side effects;
    Print runs on_confirm(pages, cols) (which handles the < 4 price tag
    confirmation, PDF/report writing, and the actual send).
    """

    THUMB_MAX_H = 420  # on-screen preview height in px; source pages are 300dpi A4

    def __init__(self, parent, label_paths, initial_cols, on_confirm, on_export=None):
        super().__init__(parent)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        self.label_paths = label_paths
        self.on_confirm = on_confirm
        self.on_export = on_export
        self.idx = 0
        self._thumb_cache = {}  # keyed by (cols, page index) -- never invalidated
        # Reused across every layout (tags-per-row) switch for this preview
        # session: opened/autocropped source images (make_a4_sheet's
        # _prepared_label) and the fully-tiled A4 pages themselves, so
        # toggling between column counts re-reads/re-composes nothing the
        # second time around -- see build_pages()'s image_cache docstring.
        self._image_cache = {}
        self._pages_by_cols = {}

        self.cols_var = tk.IntVar(value=initial_cols)
        self.pages = build_pages(label_paths, cols=initial_cols, image_cache=self._image_cache)
        self._pages_by_cols[initial_cols] = self.pages

        layout_bar = ttk.Frame(self, padding=(12, 12, 12, 0))
        layout_bar.pack(fill="x")
        ttk.Label(layout_bar, text="Tags per row:", style="Bold.TLabel").pack(side="left")
        for cols in VALID_COLS:
            ttk.Radiobutton(
                layout_bar, text=str(cols), value=cols, variable=self.cols_var,
                command=self._on_layout_changed,
            ).pack(side="left", padx=(6, 0))

        self.image_label = ttk.Label(self)
        self.image_label.pack(padx=12, pady=(8, 4))

        nav = ttk.Frame(self)
        nav.pack(pady=(0, 8))
        ttk.Button(nav, text="< Prev", command=self._prev).pack(side="left")
        self.page_indicator = ttk.Label(nav, text="")
        self.page_indicator.pack(side="left", padx=12)
        ttk.Button(nav, text="Next >", command=self._next).pack(side="left")

        bottom = ttk.Frame(self, padding=10)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Cancel", command=self.destroy).pack(side="right")
        self.print_button = ttk.Button(bottom, text="", command=self._on_print_click, style="Primary.TButton")
        self.print_button.pack(side="right", padx=(0, 6))
        if self.on_export is not None:
            ttk.Button(bottom, text="Export PDF…", command=self._on_export_click).pack(
                side="right", padx=(0, 6)
            )

        self._update_chrome()
        self._render_current()

    def _update_chrome(self):
        """Refreshes the window title, page count label, and Print button
        text -- all of which depend on how many pages the current layout
        produces."""
        self.title(f"Preview — {len(self.pages)} A4 page{'s' if len(self.pages) != 1 else ''}")
        self.print_button.configure(
            text=f"Print {len(self.pages)} page{'s' if len(self.pages) != 1 else ''}"
        )

    def _on_layout_changed(self):
        cols = self.cols_var.get()
        cached = self._pages_by_cols.get(cols)
        if cached is not None:
            # Already built this exact layout earlier in this preview
            # session (the user toggled back to a column count they'd
            # already viewed) -- reuse it outright instead of re-tiling.
            self.pages = cached
        else:
            self.pages = build_pages(self.label_paths, cols=cols, image_cache=self._image_cache)
            self._pages_by_cols[cols] = self.pages
        self.idx = min(self.idx, len(self.pages) - 1)
        self._update_chrome()
        self._render_current()

    def _thumb(self, i):
        cols = self.cols_var.get()
        key = (cols, i)
        if key not in self._thumb_cache:
            page = self.pages[i]
            scale = self.THUMB_MAX_H / page.height
            size = (max(1, round(page.width * scale)), max(1, round(page.height * scale)))
            self._thumb_cache[key] = ImageTk.PhotoImage(page.resize(size, Image.LANCZOS))
        return self._thumb_cache[key]

    def _render_current(self):
        self.image_label.configure(image=self._thumb(self.idx))
        self.page_indicator.configure(text=f"Page {self.idx + 1} of {len(self.pages)}")

    def _prev(self):
        if self.idx > 0:
            self.idx -= 1
            self._render_current()

    def _next(self):
        if self.idx < len(self.pages) - 1:
            self.idx += 1
            self._render_current()

    def _on_print_click(self):
        pages, cols = self.pages, self.cols_var.get()
        self.destroy()
        self.on_confirm(pages, cols)

    def _on_export_click(self):
        # Note: does NOT self.destroy() here -- exporting can be cancelled
        # partway (the save-file dialog), and the preview should stay open
        # in that case. on_export is responsible for closing this window
        # (via the close_preview callback) only once the export actually
        # completes.
        self.on_export(self.pages, self.cols_var.get(), self.destroy)

class TemplateEditorWindow(tk.Toplevel):
    """
    Freeform template editor. Every visible element on the tag -- product
    name, price, "RM", unit, barcode, and any custom text -- is a box that
    can be dragged, resized, restyled, or deleted, exactly like any other.
    Multiple named templates are supported (New / Duplicate / Rename /
    Delete); the one active in the main window is picked from a dropdown
    here or in the Settings sidebar.

    Nothing is written to disk until Save -- Close/Cancel is always a true
    no-op for the template file itself (New/Duplicate/Rename/Delete DO take
    effect immediately though, same as a file manager would).
    """

    CANVAS_MAX_W = 560
    HANDLE_SIZE = 10  # px, screen space -- resize-corner hit target
    MIN_BOX_SIZE = 15  # px, template-image space -- floor for both w and h,
                        # shared by corner-drag resize and the W/H spinboxes
                        # so the two interaction paths agree.

    def __init__(self, parent, start_name=None, on_close=None, start_new=False):
        super().__init__(parent)
        self.title("Template Editor")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.on_close = on_close

        self.scale = self.CANVAS_MAX_W / generate_label.TEMPLATE_REF_SIZE[0]
        self.canvas_h = round(generate_label.TEMPLATE_REF_SIZE[1] * self.scale)

        self.template = generate_label.load_template(
            start_name or generate_label.get_active_template_name()
        )
        self.selected_index = None
        self._drag = None  # set while a move/resize is in progress
        self._preview_job = None
        self._preview_photo = None
        self._dirty = False
        # Set when a rename/delete in this session changes what the
        # *active* (main-window) template is now called, so a plain Close
        # (not just "Use this template") still tells the main window.
        self._active_name_changed_to = None

        self.protocol("WM_DELETE_WINDOW", self._on_close_window)
        self._build_ui()
        self._redraw()

        if start_new:
            # Opened from the home screen's "Design New Template" button --
            # jump straight into the New-template name prompt instead of
            # landing on whatever template happened to be active. Deferred
            # one tick so this window itself finishes drawing first.
            self.after(50, self._on_new_template)

    # ---------------------------------------------------------------- UI --

    def _build_ui(self):
        top = ttk.Frame(self, padding=(14, 12, 14, 0))
        top.pack(fill="x")
        ttk.Label(top, text="Template:", style="Bold.TLabel").pack(side="left")
        self.name_var = tk.StringVar(value=self.template["name"])
        self.template_combo = ttk.Combobox(
            top, textvariable=self.name_var, state="readonly",
            values=generate_label.list_templates(), width=22,
        )
        self.template_combo.pack(side="left", padx=(6, 10))
        self.template_combo.bind("<<ComboboxSelected>>", self._on_switch_template)
        ttk.Button(top, text="New", command=self._on_new_template).pack(side="left", padx=2)
        ttk.Button(top, text="Duplicate", command=self._on_duplicate_template).pack(side="left", padx=2)
        ttk.Button(top, text="Rename", command=self._on_rename_template).pack(side="left", padx=2)
        ttk.Button(top, text="Delete", command=self._on_delete_template).pack(side="left", padx=2)
        ttk.Button(top, text="Background Image…", command=self._on_choose_background).pack(
            side="right"
        )

        body = ttk.Frame(self, padding=14)
        body.pack(fill="both", expand=True)

        # --- canvas: live preview + draggable box outlines ---
        canvas_wrap = ttk.Frame(body)
        canvas_wrap.pack(side="left")
        ttk.Label(
            canvas_wrap,
            text="Drag a box to move it, drag its bottom-right corner to resize.\n"
                 "Rendered with the sample product.",
            style="Muted.TLabel", justify="left",
        ).pack(anchor="w", pady=(0, 6))
        self.canvas = tk.Canvas(
            canvas_wrap, width=self.CANVAS_MAX_W, height=self.canvas_h,
            highlightthickness=1, highlightbackground=PALETTE["border"], background="#FFFFFF",
        )
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self._on_canvas_press)
        self.canvas.bind("<B1-Motion>", self._on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_canvas_release)

        # --- right side: box list + Add/Delete + property panel ---
        side = ttk.Frame(body, padding=(16, 0, 0, 0))
        side.pack(side="left", fill="y")

        ttk.Label(side, text="Boxes", style="Bold.TLabel").pack(anchor="w")
        self.box_listbox = tk.Listbox(side, height=6, width=30, exportselection=False)
        self.box_listbox.pack(anchor="w", pady=(2, 4))
        self.box_listbox.bind("<<ListboxSelect>>", self._on_listbox_select)

        list_btns = ttk.Frame(side)
        list_btns.pack(anchor="w", fill="x", pady=(0, 10))
        ttk.Button(list_btns, text="+ Add text box", command=self._on_add_box).pack(
            side="left"
        )
        ttk.Button(list_btns, text="Delete box", command=self._on_delete_box).pack(
            side="left", padx=(6, 0)
        )

        ttk.Separator(side).pack(fill="x", pady=(0, 10))

        self.props_frame = ttk.Frame(side)
        self.props_frame.pack(anchor="w", fill="x")
        self._build_props_widgets()

        bottom = ttk.Frame(self, padding=(14, 0, 14, 14))
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Close", command=self._on_close_window).pack(side="right")
        ttk.Button(
            bottom, text="Save", command=self._on_save, style="Primary.TButton"
        ).pack(side="right", padx=(0, 6))
        ttk.Button(
            bottom, text="Use this template", command=self._on_use_template
        ).pack(side="left")

        self._refresh_box_listbox()

    def _build_props_widgets(self):
        """Widgets for the selected box's properties. Built once; shown/hidden
        and re-populated as the selection changes (simpler than rebuilding
        the frame every click, and avoids losing focus mid-edit)."""
        f = self.props_frame

        row = ttk.Frame(f)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Content", width=10).pack(side="left")
        self.field_var = tk.StringVar()
        self.field_combo = ttk.Combobox(
            row, textvariable=self.field_var, state="readonly", width=18,
            values=[label for _, label in generate_label.FIELD_CHOICES],
        )
        self.field_combo.pack(side="left")
        self.field_combo.bind("<<ComboboxSelected>>", self._on_field_changed)

        row = ttk.Frame(f)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Text", width=10).pack(side="left")
        self.text_var = tk.StringVar()
        self.text_entry = ttk.Entry(row, textvariable=self.text_var, width=21)
        self.text_entry.pack(side="left")
        self.text_entry.bind("<KeyRelease>", self._on_text_typed)

        # X / Y / W / H
        self.pos_vars = {}
        for key, label in (("x", "X"), ("y", "Y"), ("w", "Width"), ("h", "Height")):
            row = ttk.Frame(f)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=label, width=10).pack(side="left")
            var = tk.StringVar()
            spin = ttk.Spinbox(
                row, from_=0, to=2000, textvariable=var, width=8,
                command=lambda k=key: self._on_pos_spin_changed(k),
            )
            spin.pack(side="left")
            spin.bind("<KeyRelease>", lambda e, k=key: self._on_pos_spin_changed(k))
            self.pos_vars[key] = var

        row = ttk.Frame(f)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Align", width=10).pack(side="left")
        self.align_var = tk.StringVar()
        self.align_combo = ttk.Combobox(
            row, textvariable=self.align_var, state="readonly", width=9,
            values=["left", "center", "right"],
        )
        self.align_combo.pack(side="left")
        self.align_combo.bind("<<ComboboxSelected>>", lambda e: self._on_box_field_changed("align", self.align_var.get()))

        # --- text-box-only controls ---
        self.text_only_frame = ttk.Frame(f)
        self.text_only_frame.pack(fill="x")

        row = ttk.Frame(self.text_only_frame)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Font", width=10).pack(side="left")
        self.font_var = tk.StringVar()
        self.font_combo = ttk.Combobox(
            row, textvariable=self.font_var, state="readonly", width=18,
            values=[label for _, label in generate_label.FONT_CHOICES],
        )
        self.font_combo.pack(side="left")
        self.font_combo.bind("<<ComboboxSelected>>", self._on_font_changed)

        row = ttk.Frame(self.text_only_frame)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Font size", width=10).pack(side="left")
        self.font_size_var = tk.StringVar()
        spin = ttk.Spinbox(
            row, from_=8, to=300, textvariable=self.font_size_var, width=8,
            command=lambda: self._on_int_field_changed("font_size"),
        )
        spin.pack(side="left")
        spin.bind("<KeyRelease>", lambda e: self._on_int_field_changed("font_size"))

        row = ttk.Frame(self.text_only_frame)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Max lines", width=10).pack(side="left")
        self.max_lines_var = tk.StringVar()
        spin = ttk.Spinbox(
            row, from_=1, to=10, textvariable=self.max_lines_var, width=8,
            command=lambda: self._on_int_field_changed("max_lines"),
        )
        spin.pack(side="left")
        spin.bind("<KeyRelease>", lambda e: self._on_int_field_changed("max_lines"))

        row = ttk.Frame(self.text_only_frame)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Line spacing", width=10).pack(side="left")
        self.line_spacing_var = tk.StringVar()
        spin = ttk.Spinbox(
            row, from_=8, to=300, textvariable=self.line_spacing_var, width=8,
            command=lambda: self._on_int_field_changed("line_spacing"),
        )
        spin.pack(side="left")
        spin.bind("<KeyRelease>", lambda e: self._on_int_field_changed("line_spacing"))

        row = ttk.Frame(self.text_only_frame)
        row.pack(fill="x", pady=2)
        ttk.Label(row, text="Color", width=10).pack(side="left")
        self.color_swatch = tk.Label(row, width=4, relief="solid", borderwidth=1)
        self.color_swatch.pack(side="left")
        self.color_swatch.bind("<Button-1>", self._on_pick_color)

        # --- barcode-only controls ---
        self.barcode_only_frame = ttk.Frame(f)
        self.barcode_only_frame.pack(fill="x")
        ttk.Label(
            self.barcode_only_frame,
            text="Barcode is sized in real mm for reliable\nscanning -- Width above is a cap, not a\nstretch.",
            style="Muted.TLabel", justify="left", wraplength=200,
        ).pack(anchor="w", pady=(4, 0))

        self._set_props_enabled(False)

    # ------------------------------------------------------------ redraw --

    def _img_to_canvas(self, x, y):
        return x * self.scale, y * self.scale

    def _canvas_to_img(self, cx, cy):
        return cx / self.scale, cy / self.scale

    def _box_canvas_rect(self, box):
        x0, y0 = self._img_to_canvas(box.get("x", 0), box.get("y", 0))
        x1, y1 = self._img_to_canvas(
            box.get("x", 0) + box.get("w", 100), box.get("y", 0) + box.get("h", 40)
        )
        return x0, y0, x1, y1

    def _redraw(self):
        self._render_preview_image()
        self.canvas.delete("all")
        if self._preview_photo is not None:
            self.canvas.create_image(0, 0, anchor="nw", image=self._preview_photo)
        for i, box in enumerate(self.template.get("boxes", [])):
            x0, y0, x1, y1 = self._box_canvas_rect(box)
            selected = i == self.selected_index
            color = "#2563EB" if selected else "#9CA3AF"
            width = 2 if selected else 1
            dash = () if selected else (4, 2)
            self.canvas.create_rectangle(x0, y0, x1, y1, outline=color, width=width, dash=dash)
            if selected:
                hs = self.HANDLE_SIZE
                self.canvas.create_rectangle(
                    x1 - hs, y1 - hs, x1, y1, fill=color, outline=color, tags="handle"
                )

    def _render_preview_image(self):
        try:
            sample = generate_label.get_sample_product(self.template.get("name"))
            img = compose_label(sample, template=self.template)
        except (ValueError, ZeroDivisionError, OSError):
            # transient bad in-progress value (e.g. w=0 mid-edit, or a
            # background image that failed to (re)load) -- keep last good
            # preview rather than raising into the Tk event loop.
            return
        except Exception:
            # Anything else is a real bug, not a transient mid-edit state --
            # surface it once instead of silently freezing the preview.
            traceback.print_exc()
            return
        size = (self.CANVAS_MAX_W, self.canvas_h)
        self._preview_photo = ImageTk.PhotoImage(img.resize(size, Image.LANCZOS))

    def _schedule_redraw(self):
        if self._preview_job:
            self.after_cancel(self._preview_job)
        self._preview_job = self.after(80, self._redraw)

    # ------------------------------------------------------- box list UI --

    def _box_label(self, box):
        field_labels = dict(generate_label.FIELD_CHOICES)
        base = field_labels.get(box.get("field", "text"), "Custom text")
        if box.get("field") == "text" and box.get("text"):
            snippet = box["text"][:18]
            base = f'Text: "{snippet}"'
        return base

    def _refresh_box_listbox(self):
        self.box_listbox.delete(0, "end")
        for box in self.template.get("boxes", []):
            self.box_listbox.insert("end", self._box_label(box))
        if self.selected_index is not None:
            self.box_listbox.selection_set(self.selected_index)

    def _on_listbox_select(self, event=None):
        sel = self.box_listbox.curselection()
        self.selected_index = sel[0] if sel else None
        self._sync_props_from_selection()
        self._redraw()

    # --------------------------------------------------------- selection --

    def _select_box_at(self, cx, cy):
        boxes = self.template.get("boxes", [])
        for i in reversed(range(len(boxes))):
            x0, y0, x1, y1 = self._box_canvas_rect(boxes[i])
            if x0 <= cx <= x1 and y0 <= cy <= y1:
                return i
        return None

    def _on_canvas_press(self, event):
        # resize handle on the currently-selected box takes priority
        if self.selected_index is not None:
            box = self.template["boxes"][self.selected_index]
            x0, y0, x1, y1 = self._box_canvas_rect(box)
            hs = self.HANDLE_SIZE
            if x1 - hs <= event.x <= x1 and y1 - hs <= event.y <= y1:
                self._drag = {"mode": "resize", "index": self.selected_index}
                return

        idx = self._select_box_at(event.x, event.y)
        self.selected_index = idx
        self._sync_props_from_selection()
        self._refresh_box_listbox()
        if idx is not None:
            box = self.template["boxes"][idx]
            img_x, img_y = self._canvas_to_img(event.x, event.y)
            self._drag = {
                "mode": "move", "index": idx,
                "offset_x": img_x - box.get("x", 0), "offset_y": img_y - box.get("y", 0),
            }
        self._redraw()

    def _on_canvas_drag(self, event):
        if not self._drag:
            return
        ref_w, ref_h = generate_label.TEMPLATE_REF_SIZE
        box = self.template["boxes"][self._drag["index"]]
        img_x, img_y = self._canvas_to_img(event.x, event.y)
        if self._drag["mode"] == "move":
            # Clamp so the box's own top-left can't be dragged past the far
            # edge of the template -- otherwise it's easy to lose a box
            # entirely off-canvas with no way to grab it again.
            max_x = max(0, ref_w - box.get("w", 0))
            max_y = max(0, ref_h - box.get("h", 0))
            box["x"] = min(max_x, max(0, round(img_x - self._drag["offset_x"])))
            box["y"] = min(max_y, max(0, round(img_y - self._drag["offset_y"])))
        else:  # resize
            max_w = max(self.MIN_BOX_SIZE, ref_w - box.get("x", 0))
            max_h = max(self.MIN_BOX_SIZE, ref_h - box.get("y", 0))
            box["w"] = min(max_w, max(self.MIN_BOX_SIZE, round(img_x - box.get("x", 0))))
            box["h"] = min(max_h, max(self.MIN_BOX_SIZE, round(img_y - box.get("y", 0))))
        self._mark_dirty()
        self._sync_props_from_selection(update_text_focus=False)
        self._schedule_redraw()

    def _on_canvas_release(self, event):
        self._drag = None
        self._redraw()

    # -------------------------------------------------------- properties --

    def _set_props_enabled(self, enabled):
        # Recursively walks every widget in props_frame (spinboxes, entries,
        # comboboxes) and sets its enabled state -- comboboxes get
        # "readonly" rather than "normal" so they stay selection-only.
        state = "normal" if enabled else "disabled"
        for child in self.props_frame.winfo_children():
            self._set_widget_tree_state(child, state, enabled)

    def _set_widget_tree_state(self, widget, state, enabled):
        try:
            if isinstance(widget, (ttk.Spinbox, ttk.Entry)):
                widget.configure(state=state)
            elif isinstance(widget, ttk.Combobox):
                widget.configure(state=("readonly" if enabled else "disabled"))
        except tk.TclError:
            pass
        for child in widget.winfo_children():
            self._set_widget_tree_state(child, state, enabled)

    def _sync_props_from_selection(self, update_text_focus=True):
        if self.selected_index is None:
            self._set_props_enabled(False)
            return
        self._set_props_enabled(True)
        box = self.template["boxes"][self.selected_index]
        field_labels = dict(generate_label.FIELD_CHOICES)
        self.field_var.set(field_labels.get(box.get("field", "text"), "Custom text"))
        if update_text_focus:
            self.text_var.set(box.get("text", ""))
        for key in ("x", "y", "w", "h"):
            self.pos_vars[key].set(str(box.get(key, 0)))
        self.align_var.set(box.get("align", "left"))

        is_barcode = box.get("field") == "barcode"
        if is_barcode:
            self.text_only_frame.pack_forget()
            self.barcode_only_frame.pack(fill="x")
            self.text_entry.configure(state="disabled")
        else:
            self.barcode_only_frame.pack_forget()
            self.text_only_frame.pack(fill="x")
            font_labels = dict(generate_label.FONT_CHOICES)
            self.font_var.set(font_labels.get(box.get("font", "bold"), font_labels["bold"]))
            self.font_size_var.set(str(box.get("font_size", 40)))
            self.max_lines_var.set(str(box.get("max_lines", 1)))
            self.line_spacing_var.set(str(box.get("line_spacing", 40)))
            rgb = tuple(box.get("color", [0, 0, 0]))
            self.color_swatch.configure(background="#{:02X}{:02X}{:02X}".format(*rgb))
            self.text_entry.configure(state=("normal" if box.get("field") == "text" else "disabled"))

    def _current_box(self):
        if self.selected_index is None:
            return None
        return self.template["boxes"][self.selected_index]

    def _on_box_field_changed(self, key, value):
        box = self._current_box()
        if box is None:
            return
        box[key] = value
        self._mark_dirty()
        self._refresh_box_listbox()
        self._schedule_redraw()

    def _on_field_changed(self, event=None):
        box = self._current_box()
        if box is None:
            return
        label_to_field = {label: key for key, label in generate_label.FIELD_CHOICES}
        box["field"] = label_to_field.get(self.field_var.get(), "text")
        self._sync_props_from_selection()
        self._mark_dirty()
        self._refresh_box_listbox()
        self._schedule_redraw()

    def _on_font_changed(self, event=None):
        box = self._current_box()
        if box is None:
            return
        label_to_font = {label: key for key, label in generate_label.FONT_CHOICES}
        box["font"] = label_to_font.get(self.font_var.get(), "bold")
        self._mark_dirty()
        self._schedule_redraw()

    def _on_text_typed(self, event=None):
        box = self._current_box()
        if box is None or box.get("field") != "text":
            return
        box["text"] = self.text_var.get()
        self._mark_dirty()
        self._refresh_box_listbox()
        self._schedule_redraw()

    def _on_pos_spin_changed(self, key):
        box = self._current_box()
        if box is None:
            return
        try:
            value = int(float(self.pos_vars[key].get()))
        except ValueError:
            return
        if key in ("w", "h"):
            value = max(self.MIN_BOX_SIZE, value)
        else:
            value = max(0, value)
        box[key] = value
        self._mark_dirty()
        self._schedule_redraw()

    def _on_int_field_changed(self, key):
        var = {
            "font_size": self.font_size_var,
            "max_lines": self.max_lines_var,
            "line_spacing": self.line_spacing_var,
        }[key]
        box = self._current_box()
        if box is None:
            return
        try:
            value = max(1, int(float(var.get())))
        except ValueError:
            return
        box[key] = value
        self._mark_dirty()
        self._refresh_box_listbox()
        self._schedule_redraw()

    def _on_pick_color(self, event=None):
        box = self._current_box()
        if box is None or box.get("field") == "barcode":
            return
        current = "#{:02X}{:02X}{:02X}".format(*box.get("color", [0, 0, 0]))
        picked = colorchooser.askcolor(color=current, title="Text color", parent=self)
        rgb, _hexval = picked
        if rgb is None:
            return
        box["color"] = [round(c) for c in rgb]
        self.color_swatch.configure(background="#{:02X}{:02X}{:02X}".format(*box["color"]))
        self._mark_dirty()
        self._schedule_redraw()

    # ------------------------------------------------------- box add/del --

    def _on_add_box(self):
        boxes = self.template.setdefault("boxes", [])
        # len(boxes) isn't collision-safe as an id suffix once boxes have
        # been deleted (e.g. delete box 1, add a new one, and it can collide
        # with an existing "custom_2"). Nothing currently reads box ids back,
        # but keep them actually unique so that stays true if something
        # someday does.
        existing_ids = {b.get("id") for b in boxes}
        n = len(boxes)
        new_id = f"custom_{n}"
        while new_id in existing_ids:
            n += 1
            new_id = f"custom_{n}"
        boxes.append({
            "id": new_id,
            "field": "text",
            "text": "New text",
            "x": 100, "y": 100, "w": 300, "h": 60,
            "font": "bold", "font_size": 30, "color": [0, 0, 0],
            "align": "left", "max_lines": 1, "line_spacing": 36,
        })
        self.selected_index = len(boxes) - 1
        self._mark_dirty()
        self._refresh_box_listbox()
        self._sync_props_from_selection()
        self._redraw()

    def _on_delete_box(self):
        if self.selected_index is None:
            return
        boxes = self.template["boxes"]
        del boxes[self.selected_index]
        self.selected_index = None
        self._mark_dirty()
        self._refresh_box_listbox()
        self._sync_props_from_selection()
        self._redraw()

    # ---------------------------------------------------------- template --

    def _mark_dirty(self):
        self._dirty = True

    def _confirm_discard_if_dirty(self):
        if not self._dirty:
            return True
        return messagebox.askyesno(
            "Unsaved changes",
            "This template has unsaved changes. Discard them?",
            parent=self,
        )

    def _on_switch_template(self, event=None):
        new_name = self.name_var.get()
        if new_name == self.template["name"]:
            return
        if not self._confirm_discard_if_dirty():
            self.name_var.set(self.template["name"])
            return
        self.template = generate_label.load_template(new_name)
        self.selected_index = None
        self._dirty = False
        self._refresh_box_listbox()
        self._sync_props_from_selection()
        self._redraw()

    def _on_new_template(self):
        name = self._prompt_template_name("New Template", "")
        if not name:
            return
        self.template = {"name": name, "background": "__default__", "boxes": []}
        generate_label.save_template(self.template)
        self.template_combo.configure(values=generate_label.list_templates())
        self.name_var.set(name)
        self.selected_index = None
        self._dirty = False
        self._refresh_box_listbox()
        self._sync_props_from_selection()
        self._redraw()

    def _on_duplicate_template(self):
        base = self.template["name"]
        name = self._prompt_template_name("Duplicate Template", f"{base} copy")
        if not name:
            return
        new_tpl = json.loads(json.dumps(self.template))
        new_tpl["name"] = name
        generate_label.save_template(new_tpl)
        self.template = new_tpl
        self.template_combo.configure(values=generate_label.list_templates())
        self.name_var.set(name)
        self._dirty = False
        self._refresh_box_listbox()
        self._redraw()

    def _on_rename_template(self):
        old_name = self.template["name"]
        name = self._prompt_template_name("Rename Template", old_name)
        if not name or name == old_name:
            return
        # Rename by writing the current in-memory template (which may have
        # unsaved box edits) under the new name, then removing the old file
        # -- NOT generate_label.rename_template(), which reloads the old
        # name from disk and would silently drop any pending edits still
        # only held in self.template.
        self.template["name"] = name
        try:
            generate_label.save_template(self.template)
        except OSError as e:
            self.template["name"] = old_name
            messagebox.showerror("Couldn't rename", f"Couldn't write the template file:\n{e}", parent=self)
            return
        generate_label.delete_template(old_name)
        if generate_label.get_active_template_name() == old_name:
            generate_label.set_active_template_name(name)
            self._active_name_changed_to = name
        self.template_combo.configure(values=generate_label.list_templates())
        self.name_var.set(name)
        self._dirty = False

    def _on_delete_template(self):
        name = self.template["name"]
        if name == generate_label.DEFAULT_TEMPLATE_NAME:
            messagebox.showinfo("Can't delete", "The built-in Default template can't be deleted.", parent=self)
            return
        if not messagebox.askyesno("Delete template", f'Delete the template "{name}"? This can\'t be undone.', parent=self):
            return
        generate_label.delete_template(name)
        remaining = generate_label.list_templates()
        self.template = generate_label.load_template(remaining[0])
        if generate_label.get_active_template_name() == name:
            generate_label.set_active_template_name(self.template["name"])
            self._active_name_changed_to = self.template["name"]
        self.template_combo.configure(values=remaining)
        self.name_var.set(self.template["name"])
        self.selected_index = None
        self._dirty = False
        self._refresh_box_listbox()
        self._sync_props_from_selection()
        self._redraw()

    def _prompt_template_name(self, title, initial):
        dialog = tk.Toplevel(self)
        dialog.title(title)
        dialog.transient(self)
        dialog.grab_set()
        dialog.resizable(False, False)
        ttk.Label(dialog, text="Template name:").pack(padx=14, pady=(14, 4), anchor="w")
        var = tk.StringVar(value=initial)
        entry = ttk.Entry(dialog, textvariable=var, width=30)
        entry.pack(padx=14, pady=(0, 10))
        entry.focus_set()
        entry.select_range(0, "end")
        result = {"name": None}

        def on_ok(event=None):
            name = var.get().strip()
            if not name:
                return
            existing = generate_label.list_templates()
            if name in existing and name != initial:
                if not messagebox.askyesno("Overwrite?", f'"{name}" already exists. Overwrite it?', parent=dialog):
                    return
            result["name"] = name
            dialog.destroy()

        def on_cancel():
            dialog.destroy()

        btns = ttk.Frame(dialog, padding=(14, 0, 14, 14))
        btns.pack(fill="x")
        ttk.Button(btns, text="Cancel", command=on_cancel).pack(side="right")
        ttk.Button(btns, text="OK", command=on_ok, style="Primary.TButton").pack(side="right", padx=(0, 6))
        entry.bind("<Return>", on_ok)
        dialog.wait_window()
        return result["name"]

    def _on_choose_background(self):
        path = filedialog.askopenfilename(
            title="Choose a background template image",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp"), ("All files", "*.*")],
            parent=self,
        )
        if not path:
            return
        try:
            Image.open(path).convert("RGB")
        except Exception as e:
            messagebox.showerror("Invalid image", f"Couldn't open that image:\n{e}", parent=self)
            return
        self.template["background"] = path
        self._mark_dirty()
        self._redraw()

    # -------------------------------------------------------- save/close --

    def _on_save(self):
        try:
            generate_label.save_template(self.template)
        except OSError as e:
            messagebox.showerror("Couldn't save", f"Couldn't write the template file:\n{e}", parent=self)
            return
        self._dirty = False
        if generate_label.get_active_template_name() == self.template["name"]:
            generate_label.reload_active_template()
        messagebox.showinfo("Saved", f'Template "{self.template["name"]}" saved.', parent=self)

    def _on_use_template(self):
        if self._dirty and not messagebox.askyesno(
            "Unsaved changes",
            "Save this template before using it for new price tags?",
            parent=self,
        ):
            return
        if self._dirty:
            self._on_save()
        self._close(active_name=self.template["name"])

    def _on_close_window(self):
        if not self._confirm_discard_if_dirty():
            return
        # Even on a plain Close (not "Use this template"), tell the main
        # window if a rename/delete in this session changed what the
        # active template is now called -- otherwise its dropdown is left
        # pointing at a name that no longer exists on disk.
        self._close(active_name=self._active_name_changed_to)

    def _close(self, active_name):
        if self.on_close:
            self.on_close(active_name)
        self.destroy()


def _show_fatal_error(message):
    """Last-resort error display. The app is normally launched via
    pythonw.exe (no console window -- see Start Price Tag Tool.bat), so an
    unhandled exception during startup used to just exit silently with
    nothing visible at all. Try a Tk messagebox first; if Tk itself is what
    failed to init, fall back to a raw Windows MessageBox via ctypes so
    something *always* shows up instead of a silent no-op."""
    try:
        with open(os.path.join(HERE, "crash_log.txt"), "w", encoding="utf-8") as f:
            f.write(message)
    except OSError:
        pass
    try:
        err_root = tk.Tk()
        err_root.withdraw()
        messagebox.showerror(
            "Longwan Price Tag Printer -- failed to start",
            "The app hit an error on startup:\n\n" + message +
            f"\n\nDetails were also saved to crash_log.txt next to gui.py.",
        )
        err_root.destroy()
    except Exception:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0,
                "The app hit an error on startup. See crash_log.txt next to gui.py.",
                "Longwan Price Tag Printer -- failed to start",
                0x10,  # MB_ICONERROR
            )
        except Exception:
            pass  # nothing left to try -- crash_log.txt is the only record


def main():
    try:
        root = tk.Tk()
        app = PriceTagApp(root)
        root.mainloop()
    except Exception:
        import traceback
        _show_fatal_error(traceback.format_exc())


if __name__ == "__main__":
    main()
