"""
flag_server.py
---------------
A tiny LAN-only HTTP server the desktop Price Tag Tool runs in a background
thread. The price-checker PWA (running on staff phones, same Wi-Fi/LAN)
POSTs here whenever a staff member scans a product and finds the shelf tag
price doesn't match the system price. This server just queues those flags
in memory (and mirrors them to disk so a restart doesn't lose anything
already received) -- the GUI polls the queue and lets staff review/accept
each flag into the normal print batch via the existing _add_row() flow.

Nothing here talks to the internet. It binds to 0.0.0.0 so phones on the
same LAN can reach it, but there's no outbound traffic and no cloud
dependency -- consistent with keeping this data on local infrastructure.

Endpoints
---------
GET  /api/health
    -> {"status": "ok", "branch_id": <int>, "pending": <int>, "hostname": <str>}
    Used by the PWA's "test connection" screen, and by its LAN scanner to
    label which machine it found when more than one answers.

GET  /api/lookup?barcode=<code>
    -> {"status": "ok", "items": [ {description, price, uom, barcode,
        scan_code, ...}, ... ]}
    Proxies to the same api.php the desktop tool already calls, so the
    phone never needs to reach api.php directly (avoids a CORS dead end,
    and keeps branch_id/API_URL config in one place: this file).

POST /api/flags
    body: {"device_id": "<string, optional>", "flags": [FlagItem, ...]}
    FlagItem: {
        "barcode": str,            # what was scanned (scan_code or barcode)
        "description": str,
        "uom": str,
        "system_price": str/number,   # price returned by api.php at scan time
        "shelf_price": str/number,    # price staff read off the printed tag
        "scanned_at": str (ISO8601, optional),
    }
    -> {"status": "ok", "received": <int>}

GET  /api/flags
    -> {"flags": [ {..., "id": <int>, "received_at": ...}, ... ]}
    (debug / used internally by the GUI poll loop)
"""
import json
import os
import socket
import threading
import time
from datetime import datetime, timezone

from flask import Flask, jsonify, request

from generate_label import fetch_product_by_barcode

HERE = os.path.dirname(os.path.abspath(__file__))
QUEUE_PERSIST_PATH = os.path.join(HERE, "flag_queue.json")

DEFAULT_PORT = 8765


class FlagQueue:
    """Thread-safe pending-flags queue, persisted to disk so flags received
    while the desktop app was closed aren't lost -- and so a crash mid-review
    doesn't drop anything either."""

    def __init__(self, persist_path=QUEUE_PERSIST_PATH):
        self._lock = threading.Lock()
        self._persist_path = persist_path
        self._next_id = 1
        self._items = []
        self._load()

    def _load(self):
        if os.path.exists(self._persist_path):
            try:
                with open(self._persist_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self._items = data.get("items", [])
                self._next_id = data.get("next_id", 1)
            except Exception:
                # Corrupt/partial file -- start clean rather than crash the app.
                self._items = []
                self._next_id = 1

    def _save(self):
        try:
            with open(self._persist_path, "w", encoding="utf-8") as f:
                json.dump({"items": self._items, "next_id": self._next_id}, f, indent=2)
        except Exception:
            pass  # best-effort; an in-memory queue still works this session

    def add_many(self, flags, device_id=None):
        added = []
        with self._lock:
            for flag in flags:
                item = dict(flag)
                item["id"] = self._next_id
                item["device_id"] = device_id
                item["received_at"] = datetime.now(timezone.utc).isoformat()
                self._next_id += 1
                self._items.append(item)
                added.append(item)
            self._save()
        return added

    def list_pending(self):
        with self._lock:
            return list(self._items)

    def remove(self, ids):
        ids = set(ids)
        with self._lock:
            self._items = [it for it in self._items if it["id"] not in ids]
            self._save()

    def count(self):
        with self._lock:
            return len(self._items)


def create_app(flag_queue, branch_id):
    app = Flask(__name__)

    @app.after_request
    def _add_cors(resp):
        # The PWA is served from a different origin (it's a static site /
        # installed app, not hosted by this server), so it needs CORS to
        # call this LAN endpoint from the phone's browser.
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
        return resp

    @app.route("/api/health", methods=["GET", "OPTIONS"])
    def health():
        return jsonify(
            {
                "status": "ok",
                "branch_id": branch_id,
                "pending": flag_queue.count(),
                # Lets the PWA's LAN scanner show *which* machine it found
                # when more than one flag server answers (e.g. two tills
                # running the tool on the same store Wi-Fi).
                "hostname": socket.gethostname(),
            }
        )

    @app.route("/api/lookup", methods=["GET", "OPTIONS"])
    def lookup():
        """
        Proxies a barcode lookup to the same api.php the desktop tool uses
        (fetch_product_by_barcode), server-side. This exists so the PWA
        (running in a phone browser, different origin) never has to talk to
        api.php directly -- that endpoint is a third-party LAN API with no
        CORS headers of its own, so a direct browser fetch would just fail.
        Routing through here also means staff only ever configure one
        address on their phone: this machine's LAN IP.
        """
        if request.method == "OPTIONS":
            return ("", 204)
        code = (request.args.get("barcode") or "").strip()
        if not code:
            return jsonify({"status": "error", "msg": "missing barcode"}), 400
        try:
            doc = fetch_product_by_barcode(code)
        except Exception as e:
            return jsonify({"status": "error", "msg": str(e)}), 502
        items = doc.get("items", []) if isinstance(doc, dict) else []
        if not items:
            return jsonify({"status": "error", "msg": "not found", "items": []}), 404
        return jsonify({"status": "ok", "items": items})

    @app.route("/api/flags", methods=["POST", "OPTIONS"])
    def post_flags():
        if request.method == "OPTIONS":
            return ("", 204)
        payload = request.get_json(silent=True) or {}
        flags = payload.get("flags", [])
        if not isinstance(flags, list) or not flags:
            return jsonify({"status": "error", "msg": "no flags in payload"}), 400
        device_id = payload.get("device_id")
        added = flag_queue.add_many(flags, device_id=device_id)
        return jsonify({"status": "ok", "received": len(added)})

    @app.route("/api/flags", methods=["GET"])
    def get_flags():
        return jsonify({"flags": flag_queue.list_pending()})

    return app


def run_server_in_thread(flag_queue, branch_id, port=DEFAULT_PORT, ssl_context=None):
    """Starts the Flask server on 0.0.0.0:port in a daemon thread so it dies
    with the main GUI process. Returns the thread (already started).

    If ssl_context is None, auto-detects cert.pem/key.pem sitting next to
    this file (created by make_cert.py) and serves HTTPS if found;
    otherwise falls back to plain HTTP. Pass ssl_context=False to force
    HTTP even if cert files exist.
    """
    app = create_app(flag_queue, branch_id)

    if ssl_context is None:
        cert_path = os.path.join(HERE, "cert.pem")
        key_path = os.path.join(HERE, "key.pem")
        if os.path.exists(cert_path) and os.path.exists(key_path):
            ssl_context = (cert_path, key_path)
        else:
            ssl_context = None
    elif ssl_context is False:
        ssl_context = None

    def _run():
        # use_reloader must stay False -- Flask's reloader spawns a second
        # process, which would break the shared in-memory FlagQueue.
        app.run(
            host="0.0.0.0", port=port, debug=False, use_reloader=False,
            ssl_context=ssl_context,
        )

    t = threading.Thread(target=_run, daemon=True, name="flag-server")
    t.start()
    return t


def is_https_enabled():
    """Whether cert.pem/key.pem exist next to this file -- used by the GUI
    to decide which scheme (http/https) to put in the pairing QR code."""
    return os.path.exists(os.path.join(HERE, "cert.pem")) and os.path.exists(
        os.path.join(HERE, "key.pem")
    )
