Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

Set objShell = CreateObject("WScript.Shell")
desktop = objShell.SpecialFolders("Desktop")

Set shortcut = objShell.CreateShortcut(desktop & "\Longwan Price Tag Tool.lnk")
shortcut.TargetPath = scriptDir & "\Start Price Tag Tool.bat"
shortcut.WorkingDirectory = scriptDir
shortcut.WindowStyle = 7
If fso.FileExists(scriptDir & "\assets\icon.ico") Then
    shortcut.IconLocation = scriptDir & "\assets\icon.ico"
Else
    shortcut.IconLocation = "%SystemRoot%\System32\shell32.dll,44"
End If
shortcut.Description = "Longwan Price Tag Printer"
shortcut.Save

MsgBox "Done! A ""Longwan Price Tag Tool"" icon has been added to your Desktop." & vbCrLf & vbCrLf & "From now on, just double-click that icon to open the price tag tool.", 64, "Shortcut Created"
