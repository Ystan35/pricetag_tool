@echo off
REM Allow Firewall Access.bat
REM --------------------------
REM Adds Windows Firewall inbound-allow rules for the two ports the Price
REM Tag Tool uses (8080 for the PWA static server, 8765 for the flag server),
REM so phones on the same Wi-Fi can reach them. Run this if
REM diagnose_network.py reports no existing rule, or if a phone simply can't
REM connect even though everything works on this computer.
REM
REM Must be run as Administrator: right-click this file -> "Run as administrator".

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo This needs to run as Administrator.
    echo Right-click this file and choose "Run as administrator", then try again.
    echo.
    pause
    exit /b 1
)

echo Adding firewall rules for Price Tag Tool...
echo.

netsh advfirewall firewall show rule name="Price Tag Tool - PWA (8080)" >nul 2>&1
if %errorLevel% equ 0 (
    echo Rule for port 8080 already exists, skipping.
) else (
    netsh advfirewall firewall add rule name="Price Tag Tool - PWA (8080)" dir=in action=allow protocol=TCP localport=8080
    echo Added rule for port 8080 ^(Price Checker PWA^).
)

netsh advfirewall firewall show rule name="Price Tag Tool - Flag Server (8765)" >nul 2>&1
if %errorLevel% equ 0 (
    echo Rule for port 8765 already exists, skipping.
) else (
    netsh advfirewall firewall add rule name="Price Tag Tool - Flag Server (8765)" dir=in action=allow protocol=TCP localport=8765
    echo Added rule for port 8765 ^(flag server^).
)

echo.
echo Done. Try connecting from the phone again.
echo.
pause
