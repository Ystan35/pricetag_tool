# Longwan Price Tag Generator ("HARGA BOOM" template + API injection)

## The barcode scan failure -- root cause found and fixed
Two real bugs, both in `generate_label.py` now, were causing printed barcodes
to fail scanning:

1. **The bigger one: options were silently discarded.** The script configured
   the barcode writer via `writer.set_options({...})` *before* building the
   barcode, then called `.write(buf)`. python-barcode's `Code128.render()`
   ignores any options set that way -- it only honours options passed
   directly into `.write(fp, options={...})`. So every barcode was actually
   being rendered at the library's internal fallback sizing, not the mm-based
   sizing we asked for, and rounding error at that scale corrupted bar widths
   for certain digit sequences (reproduced: `'230'`, `'100'`, `'999'`, etc.
   all failed to decode; `'2300'`, `'0215661010006'` happened to survive).
   **Fixed** by passing `options=` directly to `.write()`.
2. **A genuine data-loss bug in the library itself.** python-barcode's Code128
   size-optimizer has a lookup table that maps a leading `"99"` digit-pair to
   value 105 -- which happens to be the same as the plain START-C control
   code. The optimizer collapses `[START, 99]` down to `[105]`, silently
   **deleting** the "99" pair from the barcode instead of producing a valid
   combined symbol. Any code starting with "99" would print a barcode that
   looks fine but doesn't decode correctly. **Fixed** by disabling that
   specific optimization (`Code128._try_to_optimize`) -- costs a couple of
   extra bars in the rare case it would've applied, zero effect otherwise.

Both were verified by cross-checking every generated barcode against **two
independent decoder engines** (`pyzbar`/zbar and `zxing-cpp`) before and
after the fix, plus a self-test (`barcode_selftest()`) now runs automatically
every time a label is generated and prints a warning if a specific barcode
doesn't decode -- so any future edge case gets caught before it's printed,
not after.

Also, while chasing this: barcodes are now sized in real millimetres tied to
`LABEL_DPI` (203, the G500's native resolution) with the module width forced
to a whole-pixel count, and are never resized after generation (only
regenerated at a smaller module width if a long code needs to shrink) --
resizing was reintroducing exactly the kind of fractional-pixel blur that
caused this whole class of problem.

## What changed after the first test print (2300 / GLUCOXIT)
- **Fonts were tiny** -- fixed by bundling fonts directly in `assets/fonts/`
  instead of pointing at Linux system paths that don't exist on Windows.
- **Sizing didn't match your reference example** -- name, price, and unit
  text are now scaled up to match the reference proportions, and the
  price/unit/barcode block uses proper collision-free vertical stacking
  (each element's position is computed from the actual rendered height of
  the one below it, so long prices or wrapped 2-line names no longer
  overlap the barcode).

## Files
- `generate_label.py` -- the whole tool, including the barcode fixes above.
- `assets/template_real.png` -- your actual "HARGA BOOM" background template.
- `assets/fonts/` -- bundled fonts (Archivo Black for the title/price,
  Archivo Bold Italic for "RM"/"/ UNIT" -- both open license).
- `sample_output/` -- labels rendered from your bundled `LongWanProduct.txt`.

## Setup
```
pip install -r requirements.txt
```
`pyzbar` also needs the system `zbar` library: on Windows, `pip install pyzbar`
bundles the DLL; if you hit an import error, install the "zbar" library
separately (see pyzbar's README) -- it's only used for the optional self-test
and the tool still works fine without it (self-test just gets skipped).

## Run
```
python generate_label.py --sample
python generate_label.py --barcode 4800361382168
python generate_label.py --all-from-file LongWanProduct.txt
python generate_label.py --barcode-list gondola1.txt gondola2.txt
```

`--barcode-list` is for the "scan by batch, print once" phone workflow: an
OTG barcode scanner plugged into a phone acts as a keyboard, so scanning into
any notes/text app produces one code per line. Keep one file per gondola/aisle
(`gondola1.txt`, `gondola2.txt`, ...), sync the files to the laptop (Drive,
Dropbox, etc.), then run this once with all the files listed together --
every code gets looked up via the API and every label from every gondola is
generated in one pass, ready for a single print run. Duplicate codes (e.g. an
item re-scanned by mistake) are automatically skipped.
Watch the console -- if a barcode ever fails its own self-test, you'll see:
```
WARNING: barcode self-test FAILED to decode for code '...' -- check this label before printing.
```

## API contract (confirmed via live traffic capture of the old exe)
```
GET api.php?a=load_sku&keyword=<code>&branch_id=<id>
```
- `API_URL` -- currently `http://192.168.100.254/api.php`.
- `BRANCH_ID` -- currently `3` (`SP`) -- change per branch.

## Printing
Still outputs PNG files. Print at **100% / actual size** -- do not use "fit to
page" or any scaling in the print dialog, since that would reintroduce the
same kind of bar-width distortion we just fixed in software. For a fully
robust long-term setup, driving the G500 directly via its SDK
(`GoDEXATL64.dll`) or raw TSPL/EPL would bypass any print-driver scaling
entirely -- happy to build that next once you've confirmed a physical test
print scans reliably.
