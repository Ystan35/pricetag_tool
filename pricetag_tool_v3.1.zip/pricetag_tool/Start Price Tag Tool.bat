@echo off
setlocal enabledelayedexpansion
title Longwan Price Tag Tool
cd /d "%~dp0"

REM ---- find a working Python on this PC ----
set PYCMD=
where py >nul 2>nul
if !ERRORLEVEL!==0 (
    py -3 --version >nul 2>nul
    if !ERRORLEVEL!==0 set PYCMD=py -3
)
if "!PYCMD!"=="" (
    where python >nul 2>nul
    if !ERRORLEVEL!==0 set PYCMD=python
)
if "!PYCMD!"=="" (
    color 4F
    echo.
    echo  ============================================================
    echo   Python is not installed on this computer.
    echo.
    echo   Please install it first:
    echo     1. Go to https://www.python.org/downloads/
    echo     2. Click the yellow "Download Python" button
    echo     3. Run the installer
    echo     4. IMPORTANT: tick "Add python.exe to PATH" before clicking Install
    echo     5. After it finishes, double-click this file again
    echo  ============================================================
    echo.
    pause
    exit /b 1
)

REM ---- first-time setup: create a private copy of Python packages ----
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo  First time setup - please wait, this can take a minute...
    echo  (this only happens once)
    echo.
    !PYCMD! -m venv .venv
    if not exist ".venv\Scripts\python.exe" (
        color 4F
        echo.
        echo  Setup failed while creating the environment. Please contact support.
        echo.
        pause
        exit /b 1
    )
    ".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        color 4F
        echo.
        echo  Setup failed while installing required components.
        echo  Please check your internet connection and try again.
        echo.
        pause
        exit /b 1
    )
    REM pywin32 -- needed for direct-to-printer printing -- ships DLLs that a
    REM plain "pip install" inside a venv doesn't always finish wiring up --
    REM without this, gui.py's "import pythoncom" / "import win32api" can
    REM fail with a DLL load error before any window ever opens, and
    REM because it happens under pythonw.exe -- no console -- that failure was
    REM previously invisible. Run its post-install step explicitly so this
    REM machine's venv is actually usable. Safe to run even if it's
    REM already wired up -- postinstall.py is idempotent.
    if exist ".venv\Scripts\pywin32_postinstall.py" (
        ".venv\Scripts\python.exe" ".venv\Scripts\pywin32_postinstall.py" -install >nul 2>nul
    )
    echo.
    echo  Setup complete. Opening the price tag tool...
) else (
    REM venv already exists from a previous run -- requirements.txt can
    REM still gain a new package between updates -- this is exactly what
    REM happened with numpy: added for the autocrop feature, but existing
    REM installs never re-ran pip install and gui.py failed at import with
    REM no visible error. Quietly re-sync every launch so that class of
    REM bug can't recur silently. Cheap/no-op if everything's already
    REM installed; best-effort if offline -- won't block launch on failure.
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt --quiet >nul 2>nul
)

REM ---- launch the app with no console window ----
REM pythonw.exe has no console attached, so if gui.py throws on startup
REM -- missing font, Tk not found, bad import, etc. -- the error used to just
REM vanish -- this window would close itself 2 seconds later regardless,
REM leaving no clue the app never opened. _run_gui.bat captures
REM stdout/stderr to a log file; we then actually check whether the app
REM is still alive before deciding whether to close quietly or show what
REM went wrong.
if exist "gui_error.log" del "gui_error.log" >nul 2>nul
REM NOTE: "start "PriceTagTool" /min ..." used to leave a minimized cmd
REM window sitting in the taskbar/Alt-Tab list even after the app -- and
REM this launcher -- had both exited -- "start" spawns a brand new console
REM host for the title it's given, and that host doesn't always tear
REM itself down when its one job finishes. "start /b" runs the same
REM command as a background job of *this* console instead of opening a
REM new one, so there's no extra window to linger in the first place.
start /b "" "%~dp0_run_gui.bat"

REM ---- Price Checker PWA server: no longer auto-launched here. -----------
REM The PWA is now hosted publicly (Netlify) so phones don't need this
REM machine's LAN address just to *open* the app -- only the actual price
REM lookups/flags still need this computer, and that's still handled by
REM the flag server that starts in-process with the GUI above (see
REM flag_server.py), not this PWA static-file server.
REM If the store's internet is down and Netlify is unreachable, staff can
REM fall back to the LAN-hosted copy manually: double-click
REM "..\price-checker-pwa\Start Price Checker Server.bat" and point phones
REM at this computer's address instead (Settings -> Find automatically, or
REM type it in). See HTTPS-SETUP.md.

timeout /t 3 /nobreak >nul

tasklist /fi "imagename eq pythonw.exe" /fo csv 2>nul | findstr /i /c:"pythonw.exe" >nul
if errorlevel 1 (
    color 4F
    echo.
    echo  ============================================================
    echo   The app did not stay open -- it crashed on startup.
    echo   Here's what it reported:
    echo  ============================================================
    echo.
    if exist "gui_error.log" (
        type "gui_error.log"
    ) else (
        echo   (no error output was captured -- try running
        echo    ".venv\Scripts\python.exe" gui.py
        echo    directly from a Command Prompt in this folder to see more.)
    )
    echo.
    echo  ============================================================
    pause
    exit /b 1
)

exit
