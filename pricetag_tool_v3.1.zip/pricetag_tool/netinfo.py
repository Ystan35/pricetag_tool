"""
netinfo.py
----------
Shared LAN-IP detection, used by make_cert.py, flag_server.py, serve_https.py
(in the price-checker-pwa folder) and gui.py's Pair Phone window.

Why this exists: the old approach (opening a UDP "connection" to 8.8.8.8 and
reading back the local address the OS would use) only returns ONE address --
whichever the OS picks for its *default route*. On a machine with a VPN
client, Docker Desktop, Hyper-V, or a virtual Wi-Fi adapter installed, that
default route can point at a virtual adapter instead of the real Wi-Fi/
Ethernet one. The address it returns is still valid *for this machine*, so
the desktop app itself connects fine -- but a phone on the same physical Wi-Fi
can't reach a virtual adapter's IP, so it looks broken from the phone even
though nothing crashed. This is the #1 cause of "laptop can connect, phone
can't."

This module instead collects EVERY private IPv4 address the machine has, so:
  - make_cert.py can put all of them in the certificate (so whichever one
    turns out to be reachable, the cert still matches it)
  - the GUI can show all of them, so if the first guess doesn't work from
    the phone, there's a second (or third) address to try
"""
import socket


def _best_guess_ip():
    """The OS's pick for its default-route-out address. Usually right, but
    see module docstring for when it isn't."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return None
    finally:
        s.close()


def _is_private_ipv4(ip):
    if not ip or ip.startswith("127.") or ip.startswith("169.254."):
        return False
    parts = ip.split(".")
    if len(parts) != 4 or not all(p.isdigit() for p in parts):
        return False
    a, b = int(parts[0]), int(parts[1])
    return (
        a == 10
        or (a == 172 and 16 <= b <= 31)
        or (a == 192 and b == 168)
    )


def list_lan_ips():
    """Every private IPv4 address this machine currently has, best guess
    first, real Wi-Fi/Ethernet-looking addresses (192.168.x.x) sorted ahead
    of 10.x/172.16-31.x since those are more often VPN/corporate ranges --
    though either can be the real LAN, which is exactly why we list all of
    them instead of picking just one."""
    candidates = []

    best = _best_guess_ip()
    if _is_private_ipv4(best):
        candidates.append(best)

    try:
        _, _, addrs = socket.gethostbyname_ex(socket.gethostname())
        for ip in addrs:
            if _is_private_ipv4(ip) and ip not in candidates:
                candidates.append(ip)
    except Exception:
        pass

    if not candidates:
        candidates = ["127.0.0.1"]

    # 192.168.x.x addresses (ordinary home/office Wi-Fi) ahead of 10.x/172.16-31.x
    # (more often VPN or corporate/VLAN ranges a phone on plain Wi-Fi can't reach),
    # without disturbing the best-guess address already sitting first.
    def sort_key(ip):
        return (0 if ip == candidates[0] else 1, 0 if ip.startswith("192.168.") else 1)

    return sorted(candidates, key=sort_key)


def get_lan_ip():
    """Backwards-compatible single-IP getter (first/best candidate)."""
    return list_lan_ips()[0]


if __name__ == "__main__":
    ips = list_lan_ips()
    print("Detected LAN IP address(es), best guess first:")
    for ip in ips:
        print(f"  {ip}")
    if len(ips) > 1:
        print(
            "\nMore than one found. If the first one doesn't work from a phone,"
            " try the others -- this usually happens when a VPN, Docker Desktop,"
            " or a virtual network adapter is installed on this machine."
        )
