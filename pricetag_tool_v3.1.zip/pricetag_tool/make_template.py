"""
make_template.py
-----------------
Generates the reusable BACKGROUND TEMPLATE for the new price tag design.
This is drawn once and saved as template.png. generate_label.py then loads
this template and stamps product name / price / barcode on top of it for
every product pulled from the API.

Label size: 60mm x 40mm, landscape, at 203 DPI (Godex G500 native resolution)
Change LABEL_W_MM / LABEL_H_MM / DPI below to match your actual stock size.
"""
from PIL import Image, ImageDraw, ImageFont

# ---- label geometry (edit to match your actual label stock) ----
LABEL_W_MM = 60
LABEL_H_MM = 40
DPI = 203  # Godex G500 native print resolution

MM_TO_PX = DPI / 25.4
W = int(LABEL_W_MM * MM_TO_PX)
H = int(LABEL_H_MM * MM_TO_PX)

# ---- colors ----
FRAME_COLOR = (15, 107, 63)      # pharmacy green
BG_COLOR = (255, 255, 255)
BRAND_COLOR = (15, 107, 63)

FRAME_MARGIN = 10
FRAME_WIDTH = 4
CORNER_RADIUS = 14


def build_template(path="template.png"):
    img = Image.new("RGB", (W, H), BG_COLOR)
    draw = ImageDraw.Draw(img)

    # Outer frame
    draw.rounded_rectangle(
        [FRAME_MARGIN, FRAME_MARGIN, W - FRAME_MARGIN, H - FRAME_MARGIN],
        radius=CORNER_RADIUS,
        outline=FRAME_COLOR,
        width=FRAME_WIDTH,
    )

    # Thin inner accent line near top, separating brand strip from body
    brand_strip_bottom = FRAME_MARGIN + 34
    draw.line(
        [(FRAME_MARGIN + 8, brand_strip_bottom), (W - FRAME_MARGIN - 8, brand_strip_bottom)],
        fill=FRAME_COLOR,
        width=1,
    )

    # Brand text top-left (small)
    try:
        brand_font = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16
        )
    except OSError:
        brand_font = ImageFont.load_default()
    draw.text((FRAME_MARGIN + 10, FRAME_MARGIN + 6), "LONGWAN PHARMACY", font=brand_font, fill=BRAND_COLOR)

    img.save(path)
    print(f"Template saved: {path} ({W}x{H}px, {LABEL_W_MM}x{LABEL_H_MM}mm @ {DPI}dpi)")
    return path


if __name__ == "__main__":
    build_template()
