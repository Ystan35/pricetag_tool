"""
diagnose_network.py
--------------------
Run this when a phone can't reach the Price Checker PWA or the flag server,
even though everything works fine on the desktop computer itself. That
pattern almost always means the request never reaches this machine at all --
it's not a certificate or app bug -- and has three common causes, checked in
order below:

  1. Windows Firewall is blocking the inbound connection. This is the most
     common cause. Windows asks the first time a Python server binds to a
     network port whether to allow it through the firewall; if that prompt
     was dismissed, blocked by policy, or answered "Cancel", the port stays
     closed to other devices even though the app runs fine locally.

  2. This machine has more than one network address (VPN, Docker Desktop,
     Hyper-V, or a virtual Wi-Fi adapter all create one), and the address
     printed in the Pair Phone window / put in the certificate isn't the one
     the phone can actually reach. The desktop app still "works" because it
     can always reach itself, on any address -- only the phone notices.

  3. Router/Wi-Fi "AP isolation" (a.k.a. "client isolation") is turned on,
     which deliberately stops devices on the same Wi-Fi from reaching each
     other. Common on guest networks and some office/campus Wi-Fi.

Usage:
    python diagnose_network.py
"""
import socket
import subprocess
import sys

from netinfo import list_lan_ips

PORTS_TO_CHECK = [(8080, "Price Checker PWA (serve_https.py)"), (8765, "Flag server (flag_server.py)")]


def _print_header(text):
    print()
    print(text)
    print("-" * len(text))


def check_lan_ips():
    _print_header("1. Network addresses on this machine")
    ips = list_lan_ips()
    for i, ip in enumerate(ips):
        tag = "  <- best guess, shown in Pair Phone" if i == 0 else ""
        print(f"  {ip}{tag}")
    if len(ips) > 1:
        print(
            "\n  More than one address found. If the phone can't connect with"
            "\n  the first one, try the app with each of the others -- a phone"
            "\n  on ordinary Wi-Fi can only reach the address on that same"
            "\n  physical network, and a VPN/Docker/virtual adapter address"
            "\n  won't be it."
        )
    return ips


def check_ports_bindable():
    _print_header("2. Can this machine actually listen on the needed ports?")
    for port, label in PORTS_TO_CHECK:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("0.0.0.0", port))
            print(f"  Port {port} ({label}): free to use.")
        except OSError as e:
            print(f"  Port {port} ({label}): NOT free -- {e}")
            print(
                f"    Something else is already using port {port} (maybe this"
                f"    app is already running elsewhere?). Close it, or edit the"
                f"    port number this app uses."
            )
        finally:
            s.close()


def check_windows_firewall():
    if sys.platform != "win32":
        return
    _print_header("3. Windows Firewall")
    try:
        out = subprocess.run(
            ["netsh", "advfirewall", "show", "allprofiles", "state"],
            capture_output=True, text=True, timeout=10,
        )
        print(out.stdout.strip() or out.stderr.strip())
    except Exception as e:
        print(f"  Couldn't check firewall state automatically ({e}).")

    print()
    print("  Looking for existing allow rules for ports 8080 / 8765...")
    found_any = False
    try:
        out = subprocess.run(
            ["netsh", "advfirewall", "firewall", "show", "rule", "name=all"],
            capture_output=True, text=True, timeout=20,
        )
        text = out.stdout
        for port, label in PORTS_TO_CHECK:
            if f"LocalPort:                            {port}" in text or f"localport={port}" in text.lower():
                found_any = True
        if found_any:
            print("  Found at least one existing rule mentioning these ports.")
        else:
            print("  No existing rule found for port 8080 or 8765.")
    except Exception as e:
        print(f"  Couldn't list firewall rules ({e}).")

    if not found_any:
        print()
        print("  If Windows Firewall is the problem, run 'Allow Firewall Access.bat'")
        print("  (in this folder) as Administrator -- it adds inbound allow rules")
        print("  for ports 8080 and 8765 -- then try the phone again.")


def main():
    print("Price Tag Tool -- Network Diagnostics")
    print("=" * 38)
    print("Checking why a phone might not be able to reach this computer...")

    ips = check_lan_ips()
    check_ports_bindable()
    check_windows_firewall()

    _print_header("4. Also worth checking by hand")
    print("  - Is the phone on the SAME Wi-Fi network as this computer? (Not")
    print("    mobile data, and not a phone hotspot / different Wi-Fi band.)")
    print("  - Does the Wi-Fi have 'AP isolation' / 'client isolation' /")
    print("    'guest network' turned on? That deliberately blocks devices")
    print("    from reaching each other -- ask whoever manages the router,")
    print("    or try a phone hotspot instead as a quick test.")
    if ips:
        print(f"\n  - Try opening https://{ips[0]}:8080 in a browser ON THIS")
        print("    COMPUTER first. If even that fails, it's not a phone/Wi-Fi")
        print("    issue -- the server itself isn't reachable on that address.")
    print()
    input("Press Enter to close...")


if __name__ == "__main__":
    main()
