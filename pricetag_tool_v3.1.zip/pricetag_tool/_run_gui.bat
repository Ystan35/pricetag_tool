@echo off
REM Internal helper for "Start Price Tag Tool.bat" -- not meant to be run
REM directly. Runs the app with pythonw.exe (no console window) while
REM capturing anything it prints to gui_error.log, so a startup crash
REM leaves a trace instead of vanishing silently.
cd /d "%~dp0"
".venv\Scripts\pythonw.exe" gui.py > "gui_error.log" 2>&1
